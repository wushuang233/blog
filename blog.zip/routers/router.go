package routers

import (
	"blog/controllers"
	"blog/middleware"
	"github.com/cloudwego/hertz/pkg/app"
	"github.com/cloudwego/hertz/pkg/app/server"
	"github.com/hertz-contrib/cors"
	"time"
)

func Router() *server.Hertz {
	//h := redis.NewRedisRegistry("127.0.0.1:6379")
	r := server.Default(
		server.WithHostPorts("127.0.0.1:5212"),
		//server.WithRegistry(h, &registry.Info{
		//	ServiceName: "blog.demo",
		//	Addr:        utils.NewNetAddr("tcp", "127.0.0.1:8080"),
		//	Weight:      10,
		//	Tags:        nil,
		//}),
	)
	r.StaticFS("/static", &app.FS{Root: "./", GenerateIndexPages: true})
	r.Use(cors.New(cors.Config{
		AllowAllOrigins:  true,
		AllowMethods:     []string{"PUT", "PATCH", "GET", "POST", "DELETE", "OPTIONS"},                                         // Allowed request methods
		AllowHeaders:     []string{"Origin", "accept", "x-requested-with", "Content-Type", "X-Custom-Header", "Authorization"}, // Allowed request headers
		ExposeHeaders:    []string{"Content-Length"},                                                                           // Request headers allowed in the upload_file
		AllowCredentials: true,                                                                                                 // Whether cookies are attached
		MaxAge:           12 * time.Hour,                                                                                       // Maximum length of upload_file-side cache preflash requests (seconds)
	}))
	//store, _ := redis.NewStore(10, "tcp", "localhost:6379", "", []byte("secret"))
	//r.Use(sessions.New("mysession", store))

	index := r.Group("/")
	{
		index.POST("/register", controllers.UserController{}.Register)
		index.POST("/login", middleware.Jwtlogin().LoginHandler)
		index.PUT("/forget", controllers.UserController{}.ForgetHandler)
		index.GET("", controllers.BlogController{}.ShowBlogHandler)
		index.GET("/category", controllers.BlogController{}.ShowBlogByCategoryHandler)
		index.GET("/hot", controllers.BlogController{}.ShowBlogByHotHandler)
		index.GET("/user/id", controllers.UserController{}.GetUserByIdHandler)
		//index.GET("/user/:name", controllers.UserController{}.GetUserByNameHandler)
		index.GET("/blog", controllers.BlogController{}.GetBlogHandler)
		index.GET("/like", controllers.LikeController{}.GetLikeHandler)
		index.GET("/collection", controllers.CollectionController{}.GetCollectionHandler)
		index.GET("/all", controllers.CategoryController{}.AllCategoryHandler)
		index.GET("/userblog", controllers.UserController{}.GetBlogInfoHandler)

	}
	//用户
	user := r.Group("/user")
	{
		user.Use(middleware.Jwtlogin().MiddlewareFunc())
		user.POST("/logout", controllers.UserController{}.LogOutHandler)
		user.POST("/ping", controllers.UserController{}.PingHandler)
		user.GET("/op", controllers.UserController{}.OpHandler)
		user.GET("", controllers.UserController{}.GetUserHandler)
		user.GET("/info", controllers.UserController{}.GetInfoHandler)
		user.PUT("", controllers.UserController{}.PutUserHandler)
		user.POST("/upload", controllers.UserController{}.UploadHandler)
		user.GET("/col", controllers.UserController{}.ShowColHandler)
		user.GET("/notice", controllers.UserController{}.GetNoticeHandler)
		user.GET("/noticeinfo", controllers.UserController{}.GetNoticeInfoHandler)

	}
	blog := r.Group("/blog")
	{
		blog.Use(middleware.Jwtlogin().MiddlewareFunc())
		blog.POST("", controllers.BlogController{}.AddBlogHandler)
		blog.POST("/up", controllers.BlogController{}.UpBlogHandler)
		blog.POST("/updraft", controllers.BlogController{}.UpDraftHandler)
		blog.GET("/draft", controllers.BlogController{}.ShowDraftHandler)
		blog.GET("/put", controllers.BlogController{}.ShowPutHandler)
		blog.GET("/check", controllers.BlogController{}.ShowCheckHandler)
		blog.DELETE("", controllers.BlogController{}.DeleteBlogHandler)
		blog.PUT("", controllers.BlogController{}.ChangeBlogHandler)
		blog.POST("/front", controllers.BlogController{}.UpFrontHandler)
		blog.POST("/file", controllers.BlogController{}.UpFileHandler)
	}
	comment := r.Group("/comment")
	{
		comment.Use(middleware.Jwtlogin().MiddlewareFunc())
		comment.POST("", controllers.CommentController{}.AddCommentHandler)
		comment.GET("", controllers.CommentController{}.ShowCommentHandler)
		comment.DELETE("", controllers.CommentController{}.DelCommentHandler)
		comment.POST("/reply", controllers.ReplyController{}.AddReplyHandler)
		comment.GET("/reply", controllers.ReplyController{}.ShowReplyHandler)
	}
	//管理员
	op := r.Group("/op")
	{
		op.Use(middleware.JwtOP().MiddlewareFunc())
		op.POST("/ping", controllers.UserController{}.PingHandler)
		op.GET("/user", controllers.OpController{}.OpGetUserHandler)
		op.GET("/blog", controllers.OpController{}.OpGetBlogHandler)
		op.POST("/ban", controllers.OpController{}.OpBanUserHandler)
		op.POST("/check", controllers.OpController{}.OpCheckBlogHandler)
		op.POST("/open", controllers.OpController{}.OpOpenUserHandler)
		op.POST("/del", controllers.OpController{}.OpDelBlogHandler)
		op.POST("/top", controllers.OpController{}.OpTopHandler)
		op.POST("/deltop", controllers.OpController{}.OpDelTopHandler)
		op.POST("/notice", controllers.OpController{}.OpAddNoticeHandler)
		op.PUT("/notice", controllers.OpController{}.OpPutNoticeHandler)
		op.DELETE("/notice", controllers.OpController{}.OpDelNoticeHandler)
		op.GET("/notice", controllers.OpController{}.GetOpNoticeHandler)
	}
	//点赞
	like := r.Group("/like")
	{
		like.Use(middleware.Jwtlogin().MiddlewareFunc())
		like.POST("", controllers.LikeController{}.AddLikeHandler)
		like.GET("/judge", controllers.LikeController{}.JudgeLikeHandler)
		like.POST("/del", controllers.LikeController{}.DeleteLikeHandler)
	}
	//收藏
	col := r.Group("/col")
	{
		col.Use(middleware.Jwtlogin().MiddlewareFunc())
		col.POST("", controllers.CollectionController{}.AddCollectionHandler)
		col.GET("/judge", controllers.CollectionController{}.JudgeColHandler)
		col.POST("/del", controllers.CollectionController{}.DeleteColHandler)
	}
	sear := r.Group("/search")
	{
		sear.Use(middleware.Jwtlogin().MiddlewareFunc())
		sear.GET("", controllers.UserController{}.SearchHandler)
	}
	fan := r.Group("/fan")
	{
		fan.Use(middleware.Jwtlogin().MiddlewareFunc())
		fan.GET("", controllers.FanController{}.JudgeFanHandler)
		fan.POST("", controllers.FanController{}.FocusFanHandler)
		fan.DELETE("", controllers.FanController{}.UnFocusFanHandler)
		fan.GET("/focus", controllers.FanController{}.FocusListHandler)
		fan.GET("/fans", controllers.FanController{}.FanListHandler)
	}
	return r
}
