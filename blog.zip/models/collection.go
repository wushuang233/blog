package models

import "gorm.io/gorm"

type Collection struct {
	gorm.Model
	Id     int `query:"id" json:"id"`
	BlogId int `query:"blog_id" json:"blog_id" orm:"column(blog_id)"`
	UserId int `query:"user_id" json:"user_id"`
}

func (c Collection) TableName() string {
	return "tb_collection"
}
