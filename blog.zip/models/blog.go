package models

import "gorm.io/gorm"

type Blog struct {
	gorm.Model
	Id      int    `query:"id" json:"id"`
	Title   string `query:"title" json:"title"`
	Content string `query:"content" json:"content"`
	UserId  int    `json:"user_id"`
	//Author     string `json:"author"`
	//Avatar     string `json:"avatar"`
	CategoryId int    `json:"category_id"`
	Top        int    `json:"top"`
	Status     int    `query:"status" json:"status"`
	Resume     string `json:"resume"`
	Front      string `json:"front"`
	//Like       int64  `json:"like"`
	//Collection int64  `json:"collection"`
	//View       int64  `json:"view"`
	//Time       string `json:"time"`
}

type APIBlog struct {
	Blog       []Blog `json:"blog"`
	Like       int    `json:"like"`
	Collection int    `json:"collection"`
	View       int    `json:"view"`
}

type APICol struct {
	Id         int    `json:"id"`
	Title      string `query:"title" json:"title"`
	Content    string `query:"content" json:"content"`
	Author     string `json:"author"`
	Avatar     string `json:"avatar"`
	UserId     int    `json:"user_id"`
	CategoryId int    `json:"category_id"`
	Category   string `json:"category"`
	Resume     string `json:"resume"`
	Front      string `json:"front"`
	Like       int64  `json:"like"`
	Collection int64  `json:"collection"`
	View       int64  `json:"view"`
	Time       string `json:"time"`
	Top        int    `json:"top"`
}

func (b Blog) TableName() string {
	return "tb_blog"
}
