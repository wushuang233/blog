package models

import "gorm.io/gorm"

type Notice struct {
	gorm.Model
	Id      int    `query:"id" json:"id"`
	Title   string `json:"title"`
	Content string `json:"content"`
	Status  int    `json:"status"`
	UserId  int    `json:"user_id"`
	Time    string `json:"time"`
	Name    string `json:"name"`
}

type APINotice struct {
	Id      int    `json:"id"`
	Title   string `json:"title"`
	Content string `json:"content"`
	Time    string `json:"time"`
}

func (n Notice) TableName() string {
	return "tb_notice"
}
