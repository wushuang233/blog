package models

type View struct {
	Id     int   `json:"id"`
	BlogId int   `json:"blog_id"`
	View   int64 `json:"view"`
}

func (v View) TableName() string {
	return "tb_view"
}
