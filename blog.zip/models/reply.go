package models

import "gorm.io/gorm"

type Reply struct {
	gorm.Model
	Id        int    `json:"id"`
	CommentId int    `json:"comment_id"`
	UserId    int    `json:"user_id"`
	Time      string `json:"time"`
	Content   string `json:"content"`
	RepliedId int    `json:"replied_id"`
}

type APIReply struct {
	//gorm.Model
	Id int `json:"id"`
	//BlogId    int    `json:"blog_id"`
	CommentId int    `json:"comment_id"`
	UserId    int    `json:"user_id"`
	RepliedId int    `json:"replied_id"`
	ReplyName string `json:"replyName"`
	Content   string `json:"content"`
	Status    int    `json:"status"`
	Author    string `json:"author"`
	Avatar    string `json:"avatar"`
	Time      string `json:"time"`
}

type ReplyPage struct {
	CommentId int     `query:"comment_id" json:"comment_id"`
	PageSize  int     `query:"page_size" json:"page_size"`
	Page      int     `query:"page" json:"page"`
	PageTotal int64   `query:"page_total" json:"page_total"`
	Data      []Reply `query:"data" json:"data"`
}

func (r Reply) TableName() string {
	return "tb_reply"
}
