package models

import "gorm.io/gorm"

type Like struct {
	gorm.Model
	Id     int `query:"id" json:"id"`
	BlogId int `query:"blog_id" json:"blog_id" orm:"column(blog_id)"`
	UserId int `query:"user_id" json:"user_id"`
}

func (l Like) TableName() string {
	return "tb_like"
}
