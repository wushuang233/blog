package models

type Fan struct {
	Id       int `query:"id" json:"id"`
	AuthorId int `query:"author_id" json:"author_id"`
	FanId    int `query:"fan_id" json:"fan_id"`
}

type APIFan struct {
	Id        int    `json:"id"`
	AuthorId  int    `json:"author_id"`
	FanId     int    `json:"fan_id"`
	Name      string `json:"name"`
	Avatar    string `json:"avatar"`
	FanNumber int64  `json:"fan_number"`
}

func (f Fan) TableName() string {
	return "tb_fan"
}
