package models

type Page struct {
	PageSize   int    `query:"page_size" json:"page_size"`
	Page       int    `query:"page" json:"page"`
	PageTotal  int64  `query:"page_total" json:"page_total"`
	Data       []Blog `query:"data" json:"data"`
	CategoryId int    `query:"category_id" json:"category_id"`
	//Comment    []Comment `json:"comment"`
	//BlogId     int       `json:"blog_id"`
}
