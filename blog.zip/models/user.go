package models

import (
	"gorm.io/gorm"
)

type User struct {
	gorm.Model
	Id           int    `query:"id" json:"id"`
	Username     string `json:"username"`
	Password     string `json:"password"`
	Phone        string `json:"phone"`
	Ban          bool   `json:"ban"`
	Avatar       string `json:"avatar"`
	Email        string `json:"email"`
	Gender       int    `json:"gender"`
	Introduction string `json:"introduction"`
	Op           int    `query:"op" json:"op"`
	NickName     string `json:"nick_name"`
	Birthday     string `json:"birthday"`
	Time         string `json:"time"`
	Focus        int    `json:"focus"`
}

type APIUser struct {
	Id         int      `query:"id" json:"id"`
	Username   string   `json:"username"`
	NickName   string   `json:"nick_name"`
	Avatar     string   `json:"avatar"`
	FanNumber  int64    `json:"fan_number"`
	BlogNumber int64    `json:"blog_number"`
	BlogName   []string `json:"blog_name"`
	BlogId     []int    `json:"blog_id"`
}

type APIPage struct {
	Status    int   `query:"status" json:"status"`
	PageSize  int   `query:"page_size" json:"page_size"`
	Page      int   `query:"page" json:"page"`
	PageTotal int64 `query:"page_total" json:"page_total"`
}

type APIStatus struct {
	Id         int    `query:"id" json:"id"`
	Username   string `json:"username"`
	NickName   string `json:"nick_name"`
	Phone      string `json:"phone"`
	Email      string `json:"email"`
	BlogNumber int64  `json:"blog_number"`
	Time       string `json:"time"`
	Status     int    `json:"status"`
}

type Login struct {
	Username string `form:"username,required" json:"username,required"`
	Password string `form:"password,required" json:"password,required"`
}

func (u User) TableName() string {
	return "tb_user"
}
