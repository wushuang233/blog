package models

import "gorm.io/gorm"

type Comment struct {
	gorm.Model
	Id      int    `json:"id"`
	BlogId  int    `json:"blog_id"`
	UserId  int    `json:"user_id"`
	Content string `json:"content"`
}

type APIComment struct {
	gorm.Model
	Id      int    `json:"id"`
	BlogId  int    `json:"blog_id"`
	UserId  int    `json:"user_id"`
	Content string `json:"content"`
	Status  int    `json:"status"`
	Author  string `json:"author"`
	Avatar  string `json:"avatar"`
	Time    string `json:"time"`
}

func (c Comment) TableName() string {
	return "tb_comment"
}
