package models

type Search struct {
	PageSize  int    `query:"page_size" json:"page_size"`
	Page      int    `query:"page" json:"page"`
	PageTotal int64  `query:"page_total" json:"page_total"`
	Key       string `query:"key" json:"key"`
	Status    int    `query:"status" json:"status"`
}
