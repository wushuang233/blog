package models

type CommentPage struct {
	BlogId     int          `query:"blog_id" json:"blog_id"`
	PageSize   int          `query:"page_size" json:"page_size"`
	Page       int          `query:"page" json:"page"`
	PageTotal  int64        `query:"page_total" json:"page_total"`
	Data       []APIComment `query:"data" json:"data"`
	CategoryId int          `query:"category_id" json:"category_id"`
}
