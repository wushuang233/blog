package controllers

import (
	"blog/models"
	"blog/service"
	"context"
	"github.com/cloudwego/hertz/pkg/app"
	"github.com/cloudwego/hertz/pkg/common/utils"
)

type CategoryController struct{}

func (ca CategoryController) AllCategoryHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var categories []models.Category
	categories, err := service.AllCategory()
	if err != nil {

	}
	ctx.JSON(200, utils.H{
		"code": 200,
		"msg":  "返回所有类别",
		"data": categories,
	})
}
