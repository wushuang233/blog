package controllers

import (
	"blog/config"
	"blog/middleware"
	"blog/models"
	"blog/service"
	"context"
	"fmt"
	"github.com/cloudwego/hertz/pkg/app"
	"github.com/cloudwego/hertz/pkg/common/utils"
)

type OpController struct {
}

func (op OpController) OpGetUserHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var user models.APIPage
	_ = ctx.BindAndValidate(&user)

	key, _ := ctx.Get(middleware.JwtOP().IdentityKey)
	name := key.(*models.User).Username
	//bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	//id := bytes.Id

	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}
	var users []models.User
	var api []models.APIStatus
	api = make([]models.APIStatus, 0)
	var total int64
	offset := (user.Page - 1) * user.PageSize
	if user.Status == 1 {
		users, total, _ = service.GetOp(offset, user.PageSize)
		for _, user := range users {
			//users[i].Password = ""
			var u models.APIStatus
			u.Id = user.Id
			u.Time = user.Time
			u.NickName = user.NickName
			u.Username = user.Username
			u.Status = 1
			u.Email = user.Email
			u.Phone = user.Phone
			var blogTotal int64
			blogTotal, _ = service.CountStatus(user.Id, blogTotal, 2)
			u.BlogNumber = blogTotal
			api = append(api, u)
		}
		user.PageTotal = total
		ctx.JSON(200, utils.H{
			"code": "200",
			"msg":  "成功获取管理员列表",
			"data": api,
			"page": user,
		})
		return
	}
	if user.Status == 0 {
		users, total, _ = service.GetNormal(offset, user.PageSize)
		for _, user := range users {
			//users[i].Password = ""
			var u models.APIStatus
			u.Id = user.Id
			u.Time = user.Time
			u.NickName = user.NickName
			u.Username = user.Username
			u.Status = 0
			u.Email = user.Email
			u.Phone = user.Phone
			var blogTotal int64
			blogTotal, _ = service.CountStatus(user.Id, blogTotal, 2)
			u.BlogNumber = blogTotal
			api = append(api, u)
		}
		user.PageTotal = total
		ctx.JSON(200, utils.H{
			"code": "200",
			"msg":  "成功获取普通用户列表",
			"data": api,
			"page": user,
		})
		return
	}
	if user.Status == -1 {
		users, total, _ = service.GetBan(offset, user.PageSize)
		for _, user := range users {
			//users[i].Password = ""
			var u models.APIStatus
			u.Id = user.Id
			u.Time = user.Time
			u.NickName = user.NickName
			u.Username = user.Username
			u.Status = -1
			u.Email = user.Email
			u.Phone = user.Phone
			var blogTotal int64
			blogTotal, _ = service.CountStatus(user.Id, blogTotal, 2)
			u.BlogNumber = blogTotal
			api = append(api, u)
		}
		user.PageTotal = total
		ctx.JSON(200, utils.H{
			"code": "200",
			"msg":  "成功获取被封禁用户列表",
			"data": api,
			"page": user,
		})
		return
	}
}

func (op OpController) OpBanUserHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var user models.User
	_ = ctx.BindAndValidate(&user)

	key, _ := ctx.Get(middleware.JwtOP().IdentityKey)
	name := key.(*models.User).Username
	//bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	//id := bytes.Id

	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}

	err := service.BanUser(user)
	if err != nil {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "用户封禁失败",
		})
		return
	}
	ctx.JSON(200, utils.H{
		"code": 200,
		"msg":  "用户封禁成功",
	})
	return
}

func (op OpController) OpOpenUserHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var user models.User
	_ = ctx.BindAndValidate(&user)

	key, _ := ctx.Get(middleware.JwtOP().IdentityKey)
	name := key.(*models.User).Username
	//bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	//id := bytes.Id

	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}

	err := service.OpenUser(user)
	if err != nil {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "用户解封失败",
		})
		return
	}
	ctx.JSON(200, utils.H{
		"code": 200,
		"msg":  "用户解封成功",
	})
	return
}

func (op OpController) OpGetBlogHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var blog models.APIPage
	_ = ctx.BindAndValidate(&blog)

	key, _ := ctx.Get(middleware.JwtOP().IdentityKey)
	name := key.(*models.User).Username
	//bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	//id := bytes.Id

	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}
	var blogs []models.Blog
	var cols []models.APICol
	cols = make([]models.APICol, 0)
	var total int64
	offset := (blog.Page - 1) * blog.PageSize
	blogs, total = service.OpGetStatus(offset, blog.PageSize, blog.Status)
	blog.PageTotal = total
	if blog.Status != 1 && blog.Status != 2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "获取博客失败",
		})
		return
	}
	for _, blog := range blogs {
		var col models.APICol
		var likeTotal int64
		var colTotal int64
		var viewTotal int64
		likeTotal, err := service.CountLike(likeTotal, blog.Id)
		colTotal, err = service.CountCollection(colTotal, blog.Id)
		viewTotal, err = service.GetView(blog.Id)
		if err != nil {

		}
		col.Id = blog.Id
		col.Title = blog.Title
		col.Content = blog.Content
		col.Time = blog.UpdatedAt.Format("2006-01-02 15:04:05")
		col.CategoryId = blog.CategoryId
		col.Resume = blog.Resume
		//blogs[i].Like = likeTotal
		//blogs[i].Collection = colTotal
		//blogs[i].View = viewTotal
		col.Like = likeTotal
		col.Collection = colTotal
		col.View = viewTotal
		cols = append(cols, col)
	}
	for i, _ := range blogs {
		user, _ := service.GetUserInfoById(blogs[i].UserId)
		//blogs[i].Author = user.NickName
		//blogs[i].Avatar = user.Avatar
		cols[i].Author = user.NickName
		cols[i].Avatar = user.Avatar
		cols[i].Category, _ = service.GetCategory(cols[i].CategoryId)
		//blogs[i].Time = blogs[i].UpdatedAt.Format("2006-01-02 15:04:05")
	}
	ctx.JSON(200, utils.H{
		"code": 200,
		"msg":  "获取博客成功",
		"data": cols,
		"page": blog,
	})
	return
}

func (op OpController) OpCheckBlogHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var blog models.Blog
	_ = ctx.BindAndValidate(&blog)

	key, _ := ctx.Get(middleware.JwtOP().IdentityKey)
	name := key.(*models.User).Username
	//bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	//id := bytes.Id

	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}
	if service.IsBlog(blog.Id) == false {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "博客不存在",
		})
		return
	}
	status, _ := service.GetStatus(blog.Id)
	if status != 1 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "审核博客失败",
		})
		return
	}
	if blog.Status != 1 && blog.Status != 0 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "审核博客失败",
		})
		return
	}
	blog2, _ := service.GetBlog(blog.Id)
	//通过
	if blog.Status == 1 {
		err := service.OpCheck(blog.Id, 2)
		if err != nil {
			ctx.JSON(200, utils.H{
				"code": 404,
				"msg":  "审核博客失败",
			})
			return
		}
		//发布成功通知
		ctx.JSON(200, utils.H{
			"code": 200,
			"msg":  "审核博客已发布",
		})
		var notice models.Notice
		notice.UserId = blog2.UserId
		notice.Title = "系统通知"
		notice.Content = "你名为《" + blog2.Title + "》的博客通过了审核，成功发布！"
		notice.Name = "系统"
		service.SysAddNotice(notice)
		return
	}
	//打回
	if blog.Status == 0 {
		err := service.OpCheck(blog.Id, 0)
		if err != nil {
			ctx.JSON(200, utils.H{
				"code": 404,
				"msg":  "审核博客失败",
			})
			return
		}
		//发布打回通知
		ctx.JSON(200, utils.H{
			"code": 200,
			"msg":  "审核博客已打回草稿箱",
		})
		var notice models.Notice
		notice.UserId = blog2.UserId
		notice.Title = "系统通知"
		notice.Name = "系统"
		notice.Content = "你名为《" + blog2.Title + "》的博客未通过管理员审核，已回到你的草稿箱！未通过审核的理由为：" + blog.Content
		service.SysAddNotice(notice)
		return
	}
}

// 管理员删除博客
func (op OpController) OpDelBlogHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var blog models.Blog
	_ = ctx.BindAndValidate(&blog)

	key, _ := ctx.Get(middleware.JwtOP().IdentityKey)
	name := key.(*models.User).Username
	//bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	//id := bytes.Id

	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}
	if service.IsBlog(blog.Id) == false {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "博客不存在",
		})
		return
	}
	status, _ := service.GetStatus(blog.Id)

	if status != 2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "删除博客失败",
		})
		return
	}
	blog2, _ := service.GetBlog(blog.Id)
	//删除博客发个通知
	err := service.OpDelBlog(blog.Id, 0)
	if err != nil {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "删除博客失败",
		})
		return
	}
	//发布打回通知
	ctx.JSON(200, utils.H{
		"code": 200,
		"msg":  "该博客已打回草稿箱",
	})

	//发个通知
	var notice models.Notice
	notice.UserId = blog2.UserId
	notice.Title = "系统通知"
	notice.Name = "系统"
	notice.Content = "你名为《" + blog2.Title + "》的博客被管理员删除，已回到你的草稿箱！" + "删除理由为：" + blog.Content
	service.SysAddNotice(notice)

	return

}

// 管理员添加置顶
func (op OpController) OpTopHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var blog models.Blog
	_ = ctx.BindAndValidate(&blog)

	key, _ := ctx.Get(middleware.JwtOP().IdentityKey)
	name := key.(*models.User).Username
	//bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	//id := bytes.Id

	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}
	if service.IsBlog(blog.Id) == false {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "博客不存在",
		})
		return
	}
	blog2, _ := service.GetBlog(blog.Id)
	if blog2.Top == 1 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "该博客已置顶，无需再次置顶",
		})
		return
	}
	if blog2.Status != 2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "该博客无法置顶",
		})
		return
	}
	err := service.OpTopBLog(blog.Id)
	if err != nil {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "该博客置顶失败",
		})
		return
	}
	ctx.JSON(200, utils.H{
		"code": 200,
		"msg":  "该博客置顶成功",
	})

	//发个通知
	var notice models.Notice
	notice.UserId = blog2.UserId
	notice.Title = "系统通知"
	notice.Name = "系统"
	notice.Content = "管理员置顶了你名为《" + blog2.Title + "》的博客，请再接再励，创造更多优秀的博客吧！"
	service.SysAddNotice(notice)
	return
}

// 管理员取消置顶
func (op OpController) OpDelTopHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var blog models.Blog
	_ = ctx.BindAndValidate(&blog)

	key, _ := ctx.Get(middleware.JwtOP().IdentityKey)
	name := key.(*models.User).Username
	//bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	//id := bytes.Id

	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}
	if service.IsBlog(blog.Id) == false {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "博客不存在",
		})
		return
	}
	blog2, _ := service.GetBlog(blog.Id)
	if blog2.Top == 0 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "该博客无需取消置顶",
		})
		return
	}
	if blog2.Status != 2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "该博客无法取消置顶",
		})
		return
	}
	err := service.OpDelTopBLog(blog.Id)
	if err != nil {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "该博客取消置顶失败",
		})
		return
	}
	ctx.JSON(200, utils.H{
		"code": 200,
		"msg":  "该博客取消置顶成功",
	})
	return
}

// 管理员更新通知
func (op OpController) OpPutNoticeHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var notice models.Notice
	_ = ctx.BindAndValidate(&notice)

	key, _ := ctx.Get(middleware.JwtOP().IdentityKey)
	name := key.(*models.User).Username
	//bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	//id := bytes.Id

	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}
	notice.Name = name
	err := service.OpPutNotice(notice)
	if err != nil {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "管理员更新通知失败",
		})
		return
	}
	if service.CheckNotice(notice.Id) == false || notice.Id == 0 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "管理员更新通知失败",
		})
		return
	}
	ctx.JSON(200, utils.H{
		"code": 200,
		"msg":  "管理员成功更新通知",
	})
	return
}

// 管理员增加通知
func (op OpController) OpAddNoticeHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var notice models.Notice
	_ = ctx.BindAndValidate(&notice)

	key, _ := ctx.Get(middleware.JwtOP().IdentityKey)
	name := key.(*models.User).Username
	//bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	//id := bytes.Id

	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}
	notice.Name = name
	err := service.OpAddNotice(notice)
	if err != nil {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "管理员发布通知失败",
		})
		return
	}
	ctx.JSON(200, utils.H{
		"code": 200,
		"msg":  "管理员成功发布通知",
	})
	return
}

// 管理员删除通知
func (op OpController) OpDelNoticeHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var notice models.Notice
	_ = ctx.BindAndValidate(&notice)

	key, _ := ctx.Get(middleware.JwtOP().IdentityKey)
	name := key.(*models.User).Username
	//bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	//id := bytes.Id

	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}
	if service.CheckNotice(notice.Id) == false || notice.Id == 0 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "管理员删除通知失败",
		})
		return
	}
	err := service.DelOpNotice(notice.Id)
	if err != nil {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "管理员删除通知失败",
		})
		return
	}
	ctx.JSON(200, utils.H{
		"code": 200,
		"msg":  "管理员成功删除通知",
	})
	return
}

// 管理员获取管理员通知
func (op OpController) GetOpNoticeHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var notices []models.Notice
	var page models.Page
	_ = ctx.BindAndValidate(&page)
	offset := (page.Page - 1) * page.PageSize
	key, _ := ctx.Get(middleware.JwtOP().IdentityKey)
	name := key.(*models.User).Username
	//bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	//id := bytes.Id

	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}

	notices, err, total := service.GetOpNotice(page, offset)
	page.PageTotal = total
	if err != nil {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "获取管理员通知失败",
		})
		return
	}
	//var notice2 []models.APINotice
	for i, notice := range notices {
		//notice2[i].Id = notice.Id
		//notice2[i].Title = notice.Title
		//notice2[i].Content = notice.Content
		notices[i].Time = notice.UpdatedAt.Format("2006-01-02 15:04:05")
	}
	ctx.JSON(200, utils.H{
		"code": 200,
		"msg":  "获取管理员通知成功",
		"data": notices,
		"page": page,
	})
	return
}
