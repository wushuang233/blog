package controllers

import (
	"blog/config"
	"blog/middleware"
	"blog/models"
	"blog/service"
	"context"
	"fmt"
	"github.com/cloudwego/hertz/pkg/app"
	"github.com/cloudwego/hertz/pkg/common/json"
	"github.com/cloudwego/hertz/pkg/common/utils"
)

type BlogController struct{}

// 添加新博客到草稿箱
func (b BlogController) AddBlogHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var blog models.Blog
	_ = ctx.BindAndValidate(&blog)

	key, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := key.(*models.User).Username
	bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	id := bytes.Id
	blog.UserId = id

	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}

	//判断 title 或者 content 及 resume 是否为空
	if blog.Content == "" || blog.Title == "" {
		m := config.ReturnFalilure()
		m["msg"] = "标题或内容不得为空"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	////判断CategoryId是否合理
	//if service.FindId(blog.CategoryId) == false {
	//	m := config.ReturnFalilure()
	//	m["msg"] = "类别不存在"
	//	data, _ := json.Marshal(m)
	//	ctx.Write([]byte(data))
	//	return
	//}
	//path, err := config.Upload(ctx, "upload")
	//fmt.Println(path)
	//fmt.Println(err)
	//blog.Front = path
	//创建博客
	blogId, err := service.AddBlog(blog)
	service.AddView(models.View{BlogId: blogId})
	if err != nil {
		m := config.ReturnFalilure()
		m["msg"] = "博客添加失败"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	m := config.ReturnSuccess()
	m["msg"] = "博客添加成功"
	data, _ := json.Marshal(m)
	ctx.Write([]byte(data))
	return
}

// 直接发布博客
func (b BlogController) UpBlogHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var blog models.Blog
	_ = ctx.BindAndValidate(&blog)

	key, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := key.(*models.User).Username
	bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	id := bytes.Id
	blog.UserId = id

	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}

	//判断 title 或者 content 及 resume 是否为空
	if blog.Content == "" || blog.Title == "" || blog.Resume == "" {
		m := config.ReturnFalilure()
		m["msg"] = "标题或内容及摘要不得为空"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	//判断CategoryId是否合理
	if service.FindId(blog.CategoryId) == false || blog.CategoryId <= 0 {
		m := config.ReturnFalilure()
		m["msg"] = "类别不存在"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	blog.Status = 1
	user, _ := service.GetUserInfoById(blog.UserId)
	op, _ := service.GetUserOpByUsername(user.Username)
	if op == 1 {
		blog.Status = 2
	}
	//创建博客
	blogId, err := service.AddBlog(blog)
	service.AddView(models.View{BlogId: blogId})
	if err != nil {
		m := config.ReturnFalilure()
		m["msg"] = "博客添加失败"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	m := config.ReturnSuccess()
	m["msg"] = "博客添加成功"
	data, _ := json.Marshal(m)
	ctx.Write([]byte(data))
	return
}

// 发布草稿箱的博客
func (b BlogController) UpDraftHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var blog models.Blog
	_ = ctx.BindAndValidate(&blog)

	key, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := key.(*models.User).Username
	bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	id := bytes.Id
	blog.UserId = id
	blog.Status = 0

	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}

	if service.JudgeBlog(blog) == false {
		m := config.ReturnFalilure()
		m["msg"] = "博客不存在"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	blog, _ = service.GetBlog(blog.Id)
	//判断 title 或者 content 及 resume 是否为空
	if blog.Content == "" || blog.Title == "" || blog.Resume == "" {
		m := config.ReturnFalilure()
		m["msg"] = "标题或内容及摘要不得为空"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	//判断CategoryId是否合理
	if service.FindId(blog.CategoryId) == false || blog.CategoryId <= 0 {
		m := config.ReturnFalilure()
		m["msg"] = "类别不存在"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}

	blog.Status = 1
	op, _ := service.GetUserOpByUsername(name)
	if op == 1 {
		blog.Status = 2
	}
	//
	////创建博客
	//_, err := service.AddBlog(blog)
	err := service.ChangeStatus(blog.Id, blog.Status)
	if err != nil {
		m := config.ReturnFalilure()
		m["msg"] = "博客上传失败"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	m := config.ReturnSuccess()
	m["msg"] = "博客上传成功"
	data, _ := json.Marshal(m)
	ctx.Write([]byte(data))
	return
}

func (b BlogController) DeleteBlogHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	//获取请求
	//body, _ := ctx.Body()
	//创建实例
	var blog models.Blog
	//填充实例
	//_ = json.Unmarshal(body, &blog)
	_ = ctx.BindAndValidate(&blog)

	key, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := key.(*models.User).Username
	bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	id := bytes.Id
	blog.UserId = id

	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}

	if service.JudBlog(blog) == false {
		m := config.ReturnFalilure()
		m["msg"] = "博客删除失败"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	//删除博客
	_, err := service.DelBlog(blog)
	if err != nil {
		m := config.ReturnFalilure()
		m["msg"] = "博客删除失败"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	m := config.ReturnSuccess()
	m["msg"] = "博客删除成功"
	data, _ := json.Marshal(m)
	ctx.Write([]byte(data))
	return
}

// 显示所有博客【不分类】
func (b BlogController) ShowBlogHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	//获取请求
	body, _ := ctx.Body()
	//创建实例
	var page models.Page
	//填充实例
	_ = json.Unmarshal(body, &page)
	if page.Page <= 0 || page.PageSize <= 0 {
		m := config.ReturnFalilure()
		m["msg"] = "博客显示出错"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	//获得page和pagesize，并且计算出totalPage
	p := page.Page
	pageSize := page.PageSize
	var total int64
	_, err := service.CountBlog(total, 1)
	if err != nil {

	}
	offset := (p - 1) * pageSize
	var blogs []models.Blog
	blogs = service.ShowBlog(page, offset)
	if blogs == nil {
		m := config.ReturnFalilure()
		m["msg"] = "博客显示出错"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	m := config.ReturnSuccess()
	m["msg"] = "博客显示成功"
	m["data"] = blogs
	data, _ := json.Marshal(m)
	ctx.Write([]byte(data))
	return
}

// 显示所有博客【草稿箱】
func (b BlogController) ShowDraftHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	////获取请求
	//body, _ := ctx.Body()
	//创建实例
	var page models.Page
	page.Page = 1
	page.PageSize = 4
	_ = ctx.BindAndValidate(&page)

	key, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := key.(*models.User).Username
	bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	id := bytes.Id

	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}

	//填充实例
	//_ = json.Unmarshal(body, &page)
	if page.Page <= 0 || page.PageSize <= 0 {
		m := config.ReturnFalilure()
		m["msg"] = "博客显示出错"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	//获得page和pagesize，并且计算出totalPage
	p := page.Page
	pageSize := page.PageSize

	var total int64
	tal, err := service.CountStatus(id, total, 0)
	if err != nil {

	}
	offset := (p - 1) * pageSize

	var blogs []models.Blog
	var apicols []models.APICol
	apicols = make([]models.APICol, 0)
	page.PageTotal = total
	blogs = service.ShowStatus(page, offset, 0, id)
	if blogs == nil {
		m := config.ReturnFalilure()
		m["msg"] = "博客显示出错"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	//var blog models.Blog
	for _, blog := range blogs {
		var col models.APICol
		var likeTotal int64
		var colTotal int64
		var viewTotal int64
		likeTotal, err = service.CountLike(likeTotal, blog.Id)
		colTotal, err = service.CountCollection(colTotal, blog.Id)
		viewTotal, err = service.GetView(blog.Id)
		if err != nil {
		}
		col.Id = blog.Id
		col.Title = blog.Title
		//col.Content = blog.Content
		col.Time = blog.UpdatedAt.Format("2006-01-02 15:04:05")
		col.CategoryId = blog.CategoryId
		col.Resume = blog.Resume
		//blogs[i].Like = likeTotal
		//blogs[i].Collection = colTotal
		//blogs[i].View = viewTotal
		col.Like = likeTotal
		col.Collection = colTotal
		col.View = viewTotal
		col.UserId = blog.UserId
		apicols = append(apicols, col)
	}
	for i, _ := range blogs {
		user, _ := service.GetUserInfoById(blogs[i].UserId)
		//blogs[i].Author = user.NickName
		//blogs[i].Avatar = user.Avatar
		//blogs[i].Time = blogs[i].UpdatedAt.Format("2006-01-02 15:04:05")
		apicols[i].Avatar = user.Avatar
		apicols[i].Author = user.NickName
		apicols[i].Category, _ = service.GetCategory(apicols[i].CategoryId)
	}
	m := config.ReturnSuccess()
	m["msg"] = "博客显示成功"
	m["data"] = apicols
	m["page"] = models.Page{
		Page:      page.Page,
		PageTotal: tal,
		PageSize:  pageSize,
	}
	//m["123"] = models.APIBlog{
	//	Blog: blogs,
	//	Like: 0,
	//}
	data, _ := json.Marshal(m)
	ctx.Write([]byte(data))
	return
}

// 显示所有博客【过审】
func (b BlogController) ShowPutHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	////获取请求
	//body, _ := ctx.Body()
	//创建实例
	var page models.Page
	page.Page = 1
	page.PageSize = 4
	_ = ctx.BindAndValidate(&page)

	key, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := key.(*models.User).Username
	bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	id := bytes.Id

	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}

	//填充实例
	//_ = json.Unmarshal(body, &page)
	if page.Page <= 0 || page.PageSize <= 0 {
		m := config.ReturnFalilure()
		m["msg"] = "博客显示出错"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	//获得page和pagesize，并且计算出totalPage
	p := page.Page
	pageSize := page.PageSize

	var total int64
	tal, err := service.CountStatus(id, total, 2)
	if err != nil {

	}
	offset := (p - 1) * pageSize
	var blogs []models.Blog
	var apicols []models.APICol
	apicols = make([]models.APICol, 0)
	page.PageTotal = total
	blogs = service.ShowStatus(page, offset, 2, id)
	if blogs == nil {
		m := config.ReturnFalilure()
		m["msg"] = "博客显示出错"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	//var blog models.Blog
	for _, blog := range blogs {
		var col models.APICol
		var likeTotal int64
		var colTotal int64
		var viewTotal int64
		likeTotal, err = service.CountLike(likeTotal, blog.Id)
		colTotal, err = service.CountCollection(colTotal, blog.Id)
		viewTotal, err = service.GetView(blog.Id)
		if err != nil {
		}
		col.Id = blog.Id
		col.Title = blog.Title
		//col.Content = blog.Content
		col.Time = blog.UpdatedAt.Format("2006-01-02 15:04:05")
		col.CategoryId = blog.CategoryId
		col.Resume = blog.Resume
		col.UserId = blog.UserId
		//blogs[i].Like = likeTotal
		//blogs[i].Collection = colTotal
		//blogs[i].View = viewTotal
		col.Like = likeTotal
		col.Collection = colTotal
		col.View = viewTotal
		apicols = append(apicols, col)
	}
	for i, _ := range blogs {
		user, _ := service.GetUserInfoById(blogs[i].UserId)
		//blogs[i].Author = user.NickName
		//blogs[i].Avatar = user.Avatar
		//blogs[i].Time = blogs[i].UpdatedAt.Format("2006-01-02 15:04:05")
		apicols[i].Avatar = user.Avatar
		apicols[i].Author = user.NickName
		apicols[i].Category, _ = service.GetCategory(apicols[i].CategoryId)
	}
	m := config.ReturnSuccess()
	m["msg"] = "博客显示成功"
	m["data"] = apicols
	m["page"] = models.Page{
		Page:      page.Page,
		PageTotal: tal,
		PageSize:  pageSize,
	}
	data, _ := json.Marshal(m)
	ctx.Write([]byte(data))
	return
}

// 显示所有博客【审核中】
func (b BlogController) ShowCheckHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	////获取请求
	//body, _ := ctx.Body()
	//创建实例
	var page models.Page
	page.Page = 1
	page.PageSize = 4
	_ = ctx.BindAndValidate(&page)

	key, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := key.(*models.User).Username
	bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	id := bytes.Id

	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}

	//填充实例
	//_ = json.Unmarshal(body, &page)
	if page.Page <= 0 || page.PageSize <= 0 {
		m := config.ReturnFalilure()
		m["msg"] = "博客显示出错"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	//获得page和pagesize，并且计算出totalPage
	p := page.Page
	pageSize := page.PageSize

	var total int64
	tal, err := service.CountStatus(id, total, 1)
	if err != nil {

	}
	offset := (p - 1) * pageSize
	var blogs []models.Blog
	var apicols []models.APICol
	apicols = make([]models.APICol, 0)
	page.PageTotal = total
	blogs = service.ShowStatus(page, offset, 1, id)
	if blogs == nil {
		m := config.ReturnFalilure()
		m["msg"] = "博客显示出错"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	//var blog models.Blog
	for _, blog := range blogs {
		var col models.APICol
		var likeTotal int64
		var colTotal int64
		var viewTotal int64
		likeTotal, err = service.CountLike(likeTotal, blog.Id)
		colTotal, err = service.CountCollection(colTotal, blog.Id)
		viewTotal, err = service.GetView(blog.Id)
		if err != nil {
		}
		col.Id = blog.Id
		col.Title = blog.Title
		//col.Content = blog.Content
		col.Time = blog.UpdatedAt.Format("2006-01-02 15:04:05")
		col.CategoryId = blog.CategoryId
		col.Resume = blog.Resume
		col.UserId = blog.UserId
		//blogs[i].Like = likeTotal
		//blogs[i].Collection = colTotal
		//blogs[i].View = viewTotal
		col.Like = likeTotal
		col.Collection = colTotal
		col.View = viewTotal
		apicols = append(apicols, col)
	}
	for i, _ := range blogs {
		user, _ := service.GetUserInfoById(blogs[i].UserId)
		//blogs[i].Author = user.NickName
		//blogs[i].Avatar = user.Avatar
		//blogs[i].Time = blogs[i].UpdatedAt.Format("2006-01-02 15:04:05")
		apicols[i].Avatar = user.Avatar
		apicols[i].Author = user.NickName
		apicols[i].Category, _ = service.GetCategory(apicols[i].CategoryId)
	}
	m := config.ReturnSuccess()
	m["msg"] = "博客显示成功"
	m["data"] = apicols
	m["page"] = models.Page{
		Page:      page.Page,
		PageTotal: tal,
		PageSize:  pageSize,
	}
	data, _ := json.Marshal(m)
	ctx.Write([]byte(data))
	return
}

// 分类显示博客
func (b BlogController) ShowBlogByCategoryHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	//获取请求
	//body, _ := ctx.Body()
	//创建实例
	var page models.Page
	//填充实例
	//_ = json.Unmarshal(body, &page)
	_ = ctx.BindAndValidate(&page)
	//fmt.Println(page.Page)
	if page.Page <= 0 || page.PageSize <= 0 || service.FindId(page.CategoryId) == false || page.CategoryId <= 0 {
		m := config.ReturnFalilure()
		m["msg"] = "博客显示出错"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	//获得page和pagesize，并且计算出totalPage
	p := page.Page
	pageSize := page.PageSize
	var total int64
	tal, err := service.CountBlog(total, page.CategoryId)
	//fmt.Println(err)
	if err != nil {
		//m := config.ReturnFalilure()
		//m["msg"] = "博客显示出错2"
		//data, _ := json.Marshal(m)
		//ctx.Write([]byte(data))
		//return
	}
	offset := (p - 1) * pageSize
	var blogs []models.Blog
	blogs = service.ShowBlogByCategory(page, offset)
	var apicols []models.APICol
	apicols = make([]models.APICol, 0)
	page.PageTotal = total
	if blogs == nil {
		m := config.ReturnFalilure()
		m["msg"] = "博客显示出错"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	//var blog models.Blog
	for _, blog := range blogs {
		var col models.APICol
		var likeTotal int64
		var colTotal int64
		var viewTotal int64
		likeTotal, err = service.CountLike(likeTotal, blog.Id)
		colTotal, err = service.CountCollection(colTotal, blog.Id)
		viewTotal, err = service.GetView(blog.Id)
		if err != nil {
		}
		col.Id = blog.Id
		col.Title = blog.Title
		//col.Content = blog.Content
		col.Time = blog.UpdatedAt.Format("2006-01-02 15:04:05")
		col.CategoryId = blog.CategoryId
		col.Resume = blog.Resume
		col.UserId = blog.UserId
		//blogs[i].Like = likeTotal
		//blogs[i].Collection = colTotal
		//blogs[i].View = viewTotal
		col.Like = likeTotal
		col.Collection = colTotal
		col.View = viewTotal
		col.Top = blog.Top
		apicols = append(apicols, col)
	}
	for i, _ := range blogs {
		user, _ := service.GetUserInfoById(blogs[i].UserId)
		//blogs[i].Author = user.NickName
		//blogs[i].Avatar = user.Avatar
		//blogs[i].Time = blogs[i].UpdatedAt.Format("2006-01-02 15:04:05")
		apicols[i].Avatar = user.Avatar
		apicols[i].Author = user.NickName
		apicols[i].Category, _ = service.GetCategory(apicols[i].CategoryId)
	}
	m := config.ReturnSuccess()
	m["msg"] = "博客显示成功"
	m["data"] = apicols
	m["page"] = models.Page{
		Page:      page.Page,
		PageTotal: tal,
		PageSize:  pageSize,
	}
	data, _ := json.Marshal(m)
	ctx.Write([]byte(data))
	return
}

// 获取博客详情信息
func (b BlogController) GetBlogHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var blog models.Blog
	var col models.APICol
	err := ctx.BindAndValidate(&blog)
	if err != nil || blog.Id <= 0 {
		m := config.ReturnFalilure()
		m["msg"] = "博客获取失败"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	blog, err = service.GetBlog(blog.Id)
	if err != nil {
		m := config.ReturnFalilure()
		m["msg"] = "博客获取失败"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	//view := blog.View
	//blog.View = view + 1

	var likeTotal int64
	var colTotal int64
	//var viewTotal int64
	user, _ := service.GetUserInfoById(blog.UserId)
	col.Id = blog.Id
	col.Title = blog.Title
	col.Content = blog.Content
	col.Time = blog.UpdatedAt.Format("2006-01-02 15:04:05")
	col.CategoryId = blog.CategoryId
	col.Resume = blog.Resume
	col.UserId = blog.UserId
	//blogs[i].Like = likeTotal
	//blogs[i].Collection = colTotal
	//blogs[i].View = viewTotal
	//col.Like = likeTotal
	//col.Collection = colTotal
	//col.View = viewTotal
	//blog.Collection, err = service.CountCollection(colTotal, blog.Id)
	//blog.Like, err = service.CountLike(likeTotal, blog.Id)
	//blog.View, err = service.GetView(blog.Id)
	col.Collection, err = service.CountCollection(colTotal, blog.Id)
	col.Like, err = service.CountLike(likeTotal, blog.Id)
	col.View, err = service.GetView(blog.Id)
	status, _ := service.GetStatus(blog.Id)
	if status == 2 {
		_ = service.SetView(blog.Id)
	}
	//blog.Author = user.NickName
	//blog.Avatar = user.Avatar
	col.Author = user.NickName
	col.Avatar = user.Avatar
	col.Category, _ = service.GetCategory(col.CategoryId)
	//blog.Time = blog.UpdatedAt.Format("2006.01.02 15:04:05")
	//_, _ = service.ChangeView(blog)
	m := config.ReturnSuccess()
	m["msg"] = "博客获取成功"
	m["data"] = col

	m["author"] = user.NickName
	data, _ := json.Marshal(m)
	ctx.Write([]byte(data))

}

// 修改博客
func (b BlogController) ChangeBlogHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var blog models.Blog
	err := ctx.BindPath(&blog)

	key, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := key.(*models.User).Username
	bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	id := bytes.Id
	blog.UserId = id
	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}

	//时间的设置
	//timeFormat := time.Now().Format("2006-01-02 15:04:05")
	//blog.Time = timeFormat
	if blog.Front == "" {
		blog.Front = "static/upload/20231111/1699666301781428273.jpg"
	}
	if blog.Id <= 0 {
		m := config.ReturnFalilure()
		m["msg"] = "博客更新失败"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	if service.JudBlog(blog) == false {
		m := config.ReturnFalilure()
		m["msg"] = "博客更新失败"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	if err != nil {
		m := config.ReturnFalilure()
		m["msg"] = "博客更新失败"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	//判断 title 或者 content 是否为空
	if blog.Content == "" || blog.Title == "" {
		m := config.ReturnFalilure()
		m["msg"] = "标题或内容不得为空"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	////判断CategoryId是否合理
	//if service.FindId(blog.CategoryId) == false || blog.CategoryId <= 0 {
	//	m := config.ReturnFalilure()
	//	m["msg"] = "类别不存在"
	//	data, _ := json.Marshal(m)
	//	ctx.Write([]byte(data))
	//	return
	//}

	_, err = service.ChangeBlog(blog)
	if err != nil {
		m := config.ReturnFalilure()
		m["msg"] = "博客更新失败"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	m := config.ReturnSuccess()
	m["msg"] = "博客更新成功"
	data, _ := json.Marshal(m)
	ctx.Write([]byte(data))
	return
}

// 上传博客封面
func (b BlogController) UpFrontHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	user, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := user.(*models.User).Username
	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}
	path, err := config.Upload(ctx, "upload")
	//fmt.Println(path)
	//fmt.Println(err)
	if err != nil {
		ctx.JSON(200, utils.H{
			"code": 200,
			"msg":  "文件不合法",
		})
		return
	}
	if err == nil && path == "" {
		ctx.JSON(200, utils.H{
			"code": 200,
			"msg":  "文件不能为空",
		})
		return
	}
	//user2, _ := service.GetUserInfoByUsername(name)

	//user2.Avatar = path
	//service.SaveAvatar(user2)
	ctx.JSON(200, utils.H{
		"code": 200,
		"url":  path,
		"msg":  "文件上传成功",
	})
}

// 分类显示博客【按热度】
func (b BlogController) ShowBlogByHotHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var page models.Page
	_ = ctx.BindAndValidate(&page)
	if page.Page <= 0 || page.PageSize <= 0 || service.FindId(page.CategoryId) == false || page.CategoryId <= 0 {
		m := config.ReturnFalilure()
		m["msg"] = "博客显示出错"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	p := page.Page
	pageSize := page.PageSize
	var total int64
	tal, err := service.CountBlog(total, page.CategoryId)

	if err != nil {

	}
	offset := (p - 1) * pageSize
	var blogs []models.Blog
	var cols []models.APICol
	cols = make([]models.APICol, 0)
	blogs = service.ShowBlogByHot(page, offset)
	if blogs == nil {
		m := config.ReturnFalilure()
		m["msg"] = "博客显示出错"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	for _, blog := range blogs {
		var col models.APICol
		var likeTotal int64
		var colTotal int64
		var viewTotal int64
		likeTotal, err = service.CountLike(likeTotal, blog.Id)
		colTotal, err = service.CountCollection(colTotal, blog.Id)
		viewTotal, err = service.GetView(blog.Id)
		if err != nil {
		}
		col.Id = blog.Id
		col.Title = blog.Title
		//col.Content = blog.Content
		col.Time = blog.UpdatedAt.Format("2006-01-02 15:04:05")
		col.CategoryId = blog.CategoryId
		col.Resume = blog.Resume
		col.UserId = blog.UserId
		//blogs[i].Like = likeTotal
		//blogs[i].Collection = colTotal
		//blogs[i].View = viewTotal
		col.Like = likeTotal
		col.Collection = colTotal
		col.View = viewTotal
		col.Top = blog.Top
		cols = append(cols, col)
	}
	for i, _ := range blogs {
		user, _ := service.GetUserInfoById(blogs[i].UserId)
		//blogs[i].Author = user.NickName
		//blogs[i].Avatar = user.Avatar
		cols[i].Author = user.NickName
		cols[i].Avatar = user.Avatar
		cols[i].Category, _ = service.GetCategory(cols[i].CategoryId)
		//blogs[i].Time = blogs[i].UpdatedAt.Format("2006-01-02 15:04:05")
	}
	m := config.ReturnSuccess()
	m["msg"] = "博客显示成功"
	m["data"] = cols
	m["page"] = models.Page{
		Page:      page.Page,
		PageTotal: tal,
		PageSize:  pageSize,
	}
	data, _ := json.Marshal(m)
	ctx.Write([]byte(data))
	return
}

// 上传文件
func (b BlogController) UpFileHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	user, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := user.(*models.User).Username
	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}
	path, err := config.UploadFile(ctx, "upload")
	//fmt.Println(path)
	//fmt.Println(err)
	if err != nil {
		ctx.JSON(200, utils.H{
			"code": 200,
			"msg":  "文件不合法",
		})
		return
	}
	if err == nil && path == "" {
		ctx.JSON(200, utils.H{
			"code": 200,
			"msg":  "文件不能为空",
		})
		return
	}
	//user2, _ := service.GetUserInfoByUsername(name)

	//user2.Avatar = path
	//service.SaveAvatar(user2)
	ctx.JSON(200, utils.H{
		"code": 200,
		"url":  path,
		"msg":  "文件上传成功",
	})
}
