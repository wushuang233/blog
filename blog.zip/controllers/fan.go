package controllers

import (
	"blog/config"
	"blog/middleware"
	"blog/models"
	"blog/service"
	"context"
	"fmt"
	"github.com/cloudwego/hertz/pkg/app"
	"github.com/cloudwego/hertz/pkg/common/utils"
)

type FanController struct{}

//判断是否关注过对方

func (f FanController) JudgeFanHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var fan models.Fan
	_ = ctx.BindAndValidate(&fan)
	user, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := user.(*models.User).Username
	bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	id := bytes.Id
	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}
	if service.FindFan(fan.AuthorId, id) == true {
		ctx.JSON(200, utils.H{
			"code": 200,
			"msg":  "true",
			"data": 1,
		})
		return
	}
	ctx.JSON(200, utils.H{
		"code": 200,
		"msg":  "false",
		"data": 0,
	})
	return
}

//关注对方

func (f FanController) FocusFanHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var fan models.Fan
	_ = ctx.BindAndValidate(&fan)
	user, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := user.(*models.User).Username
	bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	id := bytes.Id
	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}
	if service.FindFan(fan.AuthorId, id) == true {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "已经关注过对方了",
		})
		return
	}
	if fan.AuthorId == id {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "不可以关注自己",
		})
		return
	}
	user, err := service.GetUserInfoById(fan.AuthorId)
	if err != nil {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "不存在此用户",
		})
		return
	}
	err = service.FocusFan(fan.AuthorId, id)
	if err != nil {
		ctx.JSON(200, utils.H{
			"code": 200,
			"msg":  "关注失败",
		})
		return
	}
	ctx.JSON(200, utils.H{
		"code": 200,
		"msg":  "关注成功",
	})
	return
}

//取关对方

func (f FanController) UnFocusFanHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var fan models.Fan
	_ = ctx.BindAndValidate(&fan)
	user, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := user.(*models.User).Username
	bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	id := bytes.Id
	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}
	if service.FindFan(fan.AuthorId, id) == false {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "你没有关注过对方",
		})
		return
	}
	if fan.AuthorId == id {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "不可以取关自己",
		})
		return
	}
	user, err := service.GetUserInfoById(fan.AuthorId)
	if err != nil {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "不存在此用户",
		})
		return
	}
	err = service.DelFan(fan.AuthorId, id)
	if err != nil {
		ctx.JSON(200, utils.H{
			"code": 200,
			"msg":  "取关失败",
		})
		return
	}
	ctx.JSON(200, utils.H{
		"code": 200,
		"msg":  "取关成功",
	})
	return
}

//获取关注列表

func (f FanController) FocusListHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var page models.Page
	_ = ctx.BindAndValidate(&page)
	//var fan models.Fan
	//_ = ctx.BindAndValidate(&fan)
	user, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := user.(*models.User).Username
	bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	id := bytes.Id
	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}
	offset := (page.Page - 1) * page.PageSize
	var fans []models.Fan
	var api []models.APIFan
	api = make([]models.APIFan, 0)
	var total int64
	fans, err, total := service.GetFocus(id, offset, page.PageSize)
	page.PageTotal = total
	for _, fan := range fans {
		var f models.APIFan
		f.Id = fan.Id
		f.AuthorId = fan.AuthorId
		f.FanId = fan.FanId
		a, _ := service.GetUserInfoById(f.AuthorId)
		//fa,_ := service.GetUserInfoById(f.FanId)
		f.Name = a.NickName
		f.Avatar = a.Avatar
		var tot int64
		tot, _ = service.CountFan(tot, a.Id)
		f.FanNumber = tot
		api = append(api, f)
	}
	if err != nil {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "获取关注列表失败",
		})
	}
	ctx.JSON(200, utils.H{
		"code": 200,
		"msg":  "成功获取关注列表",
		"data": api,
		"page": page,
	})
}

//获取粉丝列表

func (f FanController) FanListHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	//var fan models.Fan
	//_ = ctx.BindAndValidate(&fan)
	var page models.Page
	_ = ctx.BindAndValidate(&page)
	user, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := user.(*models.User).Username
	bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	id := bytes.Id
	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	offset := (page.Page - 1) * page.PageSize
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}
	var fans []models.Fan
	var api []models.APIFan
	var total int64
	fans, err, total := service.GetFans(id, offset, page.PageSize)
	page.PageTotal = total
	for _, fan := range fans {
		var f models.APIFan
		f.Id = fan.Id
		f.AuthorId = fan.AuthorId
		f.FanId = fan.FanId
		//a,_ := service.GetUserInfoById(f.AuthorId)
		fa, _ := service.GetUserInfoById(f.FanId)
		f.Name = fa.NickName
		f.Avatar = fa.Avatar
		var tot int64
		tot, _ = service.CountFan(tot, fa.Id)
		f.FanNumber = tot
		api = append(api, f)
	}
	if err != nil {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "获取关注列表失败",
		})
	}
	ctx.JSON(200, utils.H{
		"code": 200,
		"msg":  "成功获取粉丝列表",
		"data": api,
		"page": page,
	})
}
