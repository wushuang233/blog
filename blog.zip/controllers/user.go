package controllers

import (
	"blog/config"
	"blog/middleware"
	"blog/models"
	"blog/service"
	"context"
	"fmt"
	"github.com/cloudwego/hertz/pkg/app"
	"github.com/cloudwego/hertz/pkg/common/json"
	"github.com/cloudwego/hertz/pkg/common/utils"
	"time"
)

type UserController struct{}

func (u UserController) Register(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	//获取请求
	var user models.User
	err := ctx.BindAndValidate(&user)

	//加密
	username := user.Username
	password := user.Password
	email := user.Email
	phone := user.Phone
	password2 := config.EncryMd5(password)
	user.Password = password2

	m := config.ReturnSuccess()
	if username == "" || password == "" || email == "" || phone == "" {
		m = config.ReturnFalilure()
		m["msg"] = "请填写完整信息！"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	if len(username) < 4 {
		m = config.ReturnFalilure()
		m["msg"] = "账号名过短（至少4个字符）"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	if len(password) < 6 {
		m = config.ReturnFalilure()
		m["msg"] = "密码过短（至少6个字符）"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	if !config.MatchName(username) {
		m = config.ReturnFalilure()
		m["msg"] = "账户名格式不正确，只能包含英文及数字"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	if len(phone) != 11 {
		m = config.ReturnFalilure()
		m["msg"] = "手机号格式不正确"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	if !config.VerifyEmailFormat(email) {
		m = config.ReturnFalilure()
		m["msg"] = "邮箱格式不正确"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	if !config.MatchStr(password) {
		m = config.ReturnFalilure()
		m["msg"] = "至少六个最多十六个字符，至少一个字母和一个数字，不得出现特殊字符"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	user2, err := service.GetUserInfoByUsername(username)
	if user2.Id != 0 {
		m = config.ReturnFalilure()
		m["msg"] = "该用户名已被注册"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	user2, err = service.GetUserInfoByEmail(email)
	if user2.Id != 0 {
		m = config.ReturnFalilure()
		m["msg"] = "该邮箱已被注册"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	user.NickName = username
	user.Time = time.Now().Format("2006.01.02")
	user.Birthday = "2000-01-01"
	if user.Avatar == "" {
		user.Avatar = "static/upload/20231111/1699666301781428273.jpg"
	}
	_, err = service.AddUser(user)
	if err != nil {
		m = config.ReturnFalilure()
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	data, _ := json.Marshal(m)
	ctx.Write([]byte(data))
}

func (u UserController) PingHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	user, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	ctx.JSON(200, utils.H{
		"message": fmt.Sprintf("username:%v", user.(*models.User).Username),
	})
}

func (u UserController) OpHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	user, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := user.(*models.User).Username
	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}

	op, _ := service.GetUserOpByUsername(name)
	if op == 1 {
		ctx.JSON(200, utils.H{
			"code": 201,
			"msg":  fmt.Sprintf("true"),
		})
	} else {
		ctx.JSON(200, utils.H{
			"code": 200,
			"msg":  fmt.Sprintf("false"),
		})
	}

}

func (u UserController) GetUserHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	user, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := user.(*models.User).Username
	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}
	bytes, _ := service.GetUserInfoByUsername(name)
	data, _ := json.Marshal(bytes)
	//ctx.JSON(200, utils.H{
	//	"code": 200,
	//	"msg":  []byte(data),
	//})
	m := config.ReturnSuccess()
	m["msg"] = "获取成功"
	//str := string(data)
	var v interface{}
	_ = json.Unmarshal(data, &v)
	m["data"] = v
	k, _ := json.Marshal(m)
	ctx.Write([]byte(k))

}

func (u UserController) GetInfoHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	user, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := user.(*models.User).Username
	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}
	bytes, _ := service.GetUserInfoByUsername(name)
	bytes.Password = ""
	data, _ := json.Marshal(bytes)
	//ctx.JSON(200, utils.H{
	//	"code": 200,
	//	"msg":  []byte(data),
	//})
	m := config.ReturnSuccess()
	m["msg"] = "获取成功"
	//str := string(data)
	var v interface{}
	_ = json.Unmarshal(data, &v)
	m["data"] = v
	k, _ := json.Marshal(m)
	ctx.Write([]byte(k))

}

func (u UserController) PutUserHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	key, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := key.(*models.User).Username
	bytes, _ := service.GetUserInfoByUsername(name)
	id := bytes.Id
	//获取请求
	body, _ := ctx.Body()
	//创建实例
	var user models.User
	user.Id = id
	//填充实例
	_ = json.Unmarshal(body, &user)
	_, err := service.SaveUser(user)

	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}

	if err != nil || len(user.Phone) != 11 || !config.VerifyEmailFormat(user.Email) || user.Gender > 2 || user.Gender < 0 {
		m := config.ReturnFalilure()
		m["msg"] = "信息填写出错"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	m := config.ReturnSuccess()
	m["msg"] = "更新成功"
	data, _ := json.Marshal(m)
	ctx.Write([]byte(data))
	return
}

func (u UserController) ForgetHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	//获取请求
	body, _ := ctx.Body()
	//创建实例
	var user models.User

	//填充实例
	err := json.Unmarshal(body, &user)
	name := user.Username
	bytes, _ := service.GetUserInfoByUsername(name)
	id := bytes.Id
	user.Id = id
	//填充实例
	_ = json.Unmarshal(body, &user)

	user2, err := service.GetUserInfoByUsername(name)
	if err != nil {
		m := config.ReturnFalilure()
		m["msg"] = "用户不存在"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	if user2.Email == user.Email && user2.Username == name && user2.Phone == user.Phone {
		pswd := user.Password
		if len(pswd) < 6 {
			m := config.ReturnFalilure()
			m["msg"] = "密码过短，请重置"
			data, _ := json.Marshal(m)
			ctx.Write([]byte(data))
			return
		}
		if !config.MatchStr(pswd) {
			m := config.ReturnFalilure()
			m["msg"] = "至少六个最多十六个字符，至少一个字母和一个数字，不得出现特殊字符"
			data, _ := json.Marshal(m)
			ctx.Write([]byte(data))
			return
		}
		_, err := service.ChangePassword(user)
		if err != nil {
			m := config.ReturnFalilure()
			m["msg"] = "出现异常错误"
			data, _ := json.Marshal(m)
			ctx.Write([]byte(data))
			return
		}
		m := config.ReturnSuccess()
		m["msg"] = "密码重置成功"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	m := config.ReturnFalilure()
	m["msg"] = "信息不正确"
	data, _ := json.Marshal(m)
	ctx.Write([]byte(data))
	return
}

func (u UserController) GetUserByIdHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var req models.User
	err := ctx.Bind(&req)
	if err != nil {
		m := config.ReturnFalilure()
		m["msg"] = "获取用户信息失败"
		k, _ := json.Marshal(m)
		ctx.Write(k)
		return
	}
	user, err := service.GetUserInfoById(req.Id)
	if err != nil {
		m := config.ReturnFalilure()
		m["msg"] = "获取用户信息失败"
		k, _ := json.Marshal(m)
		ctx.Write(k)
		return
	}
	m := config.ReturnSuccess()
	m["msg"] = "获取用户信息成功"
	m["data"] = user
	k, _ := json.Marshal(m)
	ctx.Write(k)
}

func (u UserController) GetUserByNameHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var req models.User
	name := ctx.Param("name")
	err := ctx.BindAndValidate(&req)
	user, err2 := service.GetUserInfoByName(name)
	if name == "" && req.Username == "" {
		m := config.ReturnFalilure()
		m["msg"] = "获取用户信息失败"
		k, _ := json.Marshal(m)
		ctx.Write(k)
		return
	}
	if err2 != nil {
		user, err = service.GetUserInfoByName(req.Username)
	}
	if err != nil {
		m := config.ReturnFalilure()
		m["msg"] = "获取用户信息失败"
		k, _ := json.Marshal(m)
		ctx.Write(k)
		return
	}
	m := config.ReturnSuccess()
	m["msg"] = "获取用户信息成功"
	m["data"] = user
	k, _ := json.Marshal(m)
	ctx.Write(k)
}

func (u UserController) LogOutHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	user, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := user.(*models.User).Username
	_, _ = config.Rdb.Del(c, name).Result()
	ctx.JSON(200, utils.H{
		"code": 200,
		"msg":  name + "退出登录",
	})
}

func (u UserController) CheckHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	user, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := user.(*models.User).Username
	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}
}

func (u UserController) UploadHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	user, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := user.(*models.User).Username
	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}
	path, err := config.Upload(ctx, "upload")

	if err != nil {
		ctx.JSON(200, utils.H{
			"code": 200,
			"msg":  "文件不合法",
		})
		return
	}

	if err == nil && path == "" {
		ctx.JSON(200, utils.H{
			"code": 200,
			"msg":  "文件不能为空",
		})
		return
	}
	user2, _ := service.GetUserInfoByUsername(name)
	user2.Avatar = path
	_, err = service.SaveAvatar(user2)
	if err != nil {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "头像上传失败",
		})
	}
	ctx.JSON(200, utils.H{
		"code": 200,
		"msg":  "头像上传成功",
	})
}
func (u UserController) ShowColHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	user, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := user.(*models.User).Username
	bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	id := bytes.Id
	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}
	var page models.Page
	_ = ctx.BindAndValidate(&page)

	if page.Page <= 0 || page.PageSize <= 0 {
		m := config.ReturnFalilure()
		m["msg"] = "收藏显示出错"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	//获得page和pagesize，并且计算出totalPage
	p := page.Page
	pageSize := page.PageSize

	var total int64
	tal, err := service.CountUserCollection(total, id)
	if err != nil {

	}
	offset := (p - 1) * pageSize

	var blogs []models.Blog
	blogs = make([]models.Blog, 0)
	var apicols []models.APICol
	apicols = make([]models.APICol, 0)

	page.PageTotal = total
	var ids []int
	ids, _ = service.ReturnUserCollection(page, offset, id)
	for i := 0; i < len(ids); i++ {
		var blog models.Blog
		var col models.APICol
		blog, err = service.GetBlog(ids[i])
		if err != nil {
			tal = tal - 1
			continue
		}
		col.Id = blog.Id
		col.Title = blog.Title
		col.Content = blog.Content
		col.Time = blog.UpdatedAt.Format("2006-01-02 15:04:05")
		col.CategoryId = blog.CategoryId
		col.Resume = blog.Resume
		col.UserId = blog.UserId
		blogs = append(blogs, blog)
		apicols = append(apicols, col)
	}
	for i, _ := range blogs {
		user, _ := service.GetUserInfoById(blogs[i].UserId)
		apicols[i].Avatar = user.Avatar
		apicols[i].Author = user.NickName
		//blogs[i].Author = user.NickName
		//blogs[i].Avatar = user.Avatar
		//blogs[i].Time = blogs[i].UpdatedAt.Format("2006-01-02 15:04:05")
	}
	if blogs == nil {
		m := config.ReturnFalilure()
		m["msg"] = "收藏显示出错"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	for i, blog := range blogs {
		var likeTotal int64
		var colTotal int64
		likeTotal, err = service.CountLike(likeTotal, blog.Id)
		colTotal, err = service.CountCollection(colTotal, blog.Id)
		if err != nil {
		}
		//blogs[i].Like = likeTotal
		//blogs[i].Collection = colTotal
		apicols[i].Like = likeTotal
		apicols[i].Collection = colTotal
		apicols[i].View, _ = service.GetView(blog.Id)
		apicols[i].Category, _ = service.GetCategory(apicols[i].CategoryId)
	}
	m := config.ReturnSuccess()
	m["msg"] = "收藏显示成功"
	m["data"] = apicols
	m["page"] = models.Page{
		Page:      page.Page,
		PageTotal: tal,
		PageSize:  pageSize,
	}
	data, _ := json.Marshal(m)
	ctx.Write([]byte(data))
	return
}

// 获取博客作者详情信息
func (u UserController) GetBlogInfoHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var user models.User
	_ = ctx.BindAndValidate(&user)
	user, _ = service.GetUserInfoById(user.Id)
	var blogTotal int64
	blogTotal, _ = service.CountStatus(user.Id, blogTotal, 2)
	var fanTotal int64
	fanTotal, _ = service.CountFan(fanTotal, user.Id)
	num, ids := service.ShowName(2, user.Id)
	ctx.JSON(200, utils.H{
		"code": 200,
		"msg":  "博客作者获取成功",
		"author": models.APIUser{
			Id:         user.Id,
			Username:   user.Username,
			Avatar:     user.Avatar,
			NickName:   user.NickName,
			BlogNumber: blogTotal,
			BlogName:   num,
			FanNumber:  fanTotal,
			BlogId:     ids,
		},
	})
}

// 搜索
func (u UserController) SearchHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var search models.Search
	_ = ctx.BindAndValidate(&search)

	keys, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	if keys == nil {
		return
	}
	name := keys.(*models.User).Username
	bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	id := bytes.Id

	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	//ctx.JSON(200, utils.H{
	//	"code": 404,
	//	"msg":  "博客获取失败",
	//})
	if str == "" {

	}
	if str != str2 {

	}

	status := search.Status
	key := search.Key
	offset := (search.Page - 1) * search.PageSize
	if status == 0 {
		//博客
		var blogs []models.Blog
		var cols []models.APICol
		blogs, err, total := service.SearchBlog(key, offset, search.PageSize)
		search.PageTotal = total
		if err != nil {
			ctx.JSON(200, utils.H{
				"code": 404,
				"msg":  "博客获取失败",
			})
			return
		}
		for _, blog := range blogs {
			var col models.APICol
			var likeTotal int64
			var colTotal int64
			var viewTotal int64
			likeTotal, err = service.CountLike(likeTotal, blog.Id)
			colTotal, err = service.CountCollection(colTotal, blog.Id)
			viewTotal, err = service.GetView(blog.Id)
			if err != nil {
			}
			col.Id = blog.Id
			col.Title = blog.Title
			col.Content = blog.Content
			col.Time = blog.UpdatedAt.Format("2006-01-02 15:04:05")
			col.CategoryId = blog.CategoryId
			col.Resume = blog.Resume
			col.UserId = blog.UserId
			//blogs[i].Like = likeTotal
			//blogs[i].Collection = colTotal
			//blogs[i].View = viewTotal
			col.Like = likeTotal
			col.Collection = colTotal
			col.View = viewTotal
			cols = append(cols, col)
		}
		for i, _ := range blogs {
			user, _ := service.GetUserInfoById(blogs[i].UserId)
			//blogs[i].Author = user.NickName
			//blogs[i].Avatar = user.Avatar
			cols[i].Author = user.NickName
			cols[i].Avatar = user.Avatar
			cols[i].Category, _ = service.GetCategory(cols[i].CategoryId)
			//blogs[i].Time = blogs[i].UpdatedAt.Format("2006-01-02 15:04:05")
		}
		ctx.JSON(200, utils.H{
			"code": 200,
			"msg":  "博客获取成功",
			"data": cols,
			"page": search,
		})
		return
	}
	if status == 1 {
		//用户
		var users []models.User
		users, err, total := service.SearchUser(key, offset, search.PageSize)
		search.PageTotal = total
		for i, _ := range users {
			users[i].Password = ""
			if service.FindFan(users[i].Id, id) == true {
				users[i].Focus = 1
			}
		}
		if err != nil {
			ctx.JSON(200, utils.H{
				"code": 404,
				"msg":  "用户获取失败",
			})
			return
		}
		ctx.JSON(200, utils.H{
			"code": 200,
			"msg":  "用户获取成功",
			"data": users,
			"page": search,
		})
		return
	}
}

// 获取用户的通知列表
func (u UserController) GetNoticeHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var notices []models.Notice
	var page models.Page
	_ = ctx.BindAndValidate(&page)
	offset := (page.Page - 1) * page.PageSize
	key, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := key.(*models.User).Username
	bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	id := bytes.Id

	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}

	notices, err, total := service.GetNotice(page, offset, id)
	page.PageTotal = total
	if err != nil {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "获取用户通知失败",
		})
		return
	}
	for i, notice := range notices {
		notices[i].Time = notice.UpdatedAt.Format("2006-01-02 15:04:05")
	}
	ctx.JSON(200, utils.H{
		"code": 200,
		"msg":  "获取用户通知成功",
		"data": notices,
		"page": page,
	})
	return
}

// 获取通知详情
func (u UserController) GetNoticeInfoHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var notice models.Notice
	_ = ctx.BindAndValidate(&notice)

	key, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := key.(*models.User).Username
	bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	id := bytes.Id

	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}
	notice, err := service.GetNoticeInfo(notice.Id, id)
	if err != nil {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  "获取通知失败",
		})
		return
	}

	ctx.JSON(200, utils.H{
		"code": 200,
		"msg":  "获取通知成功",
		"data": notice,
	})
	return
}
