package controllers

import (
	"blog/config"
	"blog/middleware"
	"blog/models"
	"blog/service"
	"context"
	"fmt"
	"github.com/cloudwego/hertz/pkg/app"
	"github.com/cloudwego/hertz/pkg/common/json"
	"github.com/cloudwego/hertz/pkg/common/utils"
)

type LikeController struct{}

func (l LikeController) AddLikeHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var like models.Like
	err := ctx.BindPath(&like)

	key, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := key.(*models.User).Username
	bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	id := bytes.Id
	like.UserId = id

	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}
	if err != nil {
		m := config.ReturnFalilure()
		m["msg"] = "点赞添加出错"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	if like.UserId <= 0 || like.BlogId <= 0 {
		m := config.ReturnFalilure()
		m["msg"] = "点赞添加出错"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	if service.FindLike(like) == true {
		m := config.ReturnFalilure()
		m["msg"] = "点赞添加出错"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	if service.IsBlog(like.BlogId) == false {
		m := config.ReturnFalilure()
		m["msg"] = "点赞添加出错"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	_, err = service.AddLike(like)
	if err != nil {

	}
	m := config.ReturnSuccess()
	m["msg"] = "点赞添加成功"
	data, _ := json.Marshal(m)
	ctx.Write([]byte(data))
	return
}

func (l LikeController) GetLikeHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var like models.Like
	err := ctx.Bind(&like)

	if err != nil {
		m := config.ReturnFalilure()
		m["msg"] = "点赞查询出错"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	if like.BlogId <= 0 {
		m := config.ReturnFalilure()
		m["msg"] = "点赞查询出错"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	if service.IsBlog(like.BlogId) == false {
		m := config.ReturnFalilure()
		m["msg"] = "点赞查询出错"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	var total int64
	total, err = service.CountLike(total, like.BlogId)
	if err != nil {

	}
	m := config.ReturnSuccess()
	m["msg"] = "点赞查询成功"
	m["data"] = total
	data, _ := json.Marshal(m)
	ctx.Write([]byte(data))
	return
}

func (l LikeController) JudgeLikeHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var like models.Like
	err := ctx.Bind(&like)

	key, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := key.(*models.User).Username
	bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	id := bytes.Id
	like.UserId = id

	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		//ctx.JSON(200, utils.H{
		//	"code": 404,
		//	"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		//})
		//return
		m := config.ReturnSuccess()
		m["msg"] = "点赞未添加"
		m["data"] = 0
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	if str != str2 {
		//ctx.JSON(200, utils.H{
		//	"code": 404,
		//	"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		//})
		//return
		m := config.ReturnSuccess()
		m["msg"] = "点赞未添加"
		m["data"] = 0
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}

	if err != nil {
		m := config.ReturnFalilure()
		m["msg"] = "点赞查询出错"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	if like.BlogId <= 0 {
		m := config.ReturnFalilure()
		m["msg"] = "点赞查询出错"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	if service.IsBlog(like.BlogId) == false {
		m := config.ReturnFalilure()
		m["msg"] = "点赞查询出错"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}

	if service.FindLike(like) == true {
		m := config.ReturnSuccess()
		m["msg"] = "点赞已添加"
		m["data"] = 1
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}

	m := config.ReturnSuccess()
	m["msg"] = "点赞未添加"
	m["data"] = 0
	data, _ := json.Marshal(m)
	ctx.Write([]byte(data))
	return
}

func (l LikeController) DeleteLikeHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")

	var like models.Like
	_ = ctx.BindAndValidate(&like)

	key, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := key.(*models.User).Username
	bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	id := bytes.Id
	like.UserId = id

	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}
	if service.IsBlog(like.BlogId) == false {
		m := config.ReturnFalilure()
		m["msg"] = "该博客不存在"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	if service.FindLike(like) == false {
		m := config.ReturnFalilure()
		m["msg"] = "点赞取消失败"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	_, err := service.DelLike(like)
	if err != nil {
		m := config.ReturnFalilure()
		m["msg"] = "点赞取消失败"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	m := config.ReturnSuccess()
	m["msg"] = "点赞取消成功"
	data, _ := json.Marshal(m)
	ctx.Write([]byte(data))
	return
}
