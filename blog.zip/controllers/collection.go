package controllers

import (
	"blog/config"
	"blog/middleware"
	"blog/models"
	"blog/service"
	"context"
	"fmt"
	"github.com/cloudwego/hertz/pkg/app"
	"github.com/cloudwego/hertz/pkg/common/json"
	"github.com/cloudwego/hertz/pkg/common/utils"
)

type CollectionController struct{}

func (coll CollectionController) AddCollectionHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	key, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	if key == nil {
		return
	}
	name := key.(*models.User).Username
	bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	id := bytes.Id
	var col models.Collection
	err := ctx.Bind(&col)
	col.UserId = id

	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}

	if err != nil {
		m := config.ReturnFalilure()
		m["msg"] = "收藏添加出错"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	if col.UserId <= 0 || col.BlogId <= 0 {
		m := config.ReturnFalilure()
		m["msg"] = "收藏添加出错"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	if service.IsBlog(col.BlogId) == false {
		m := config.ReturnFalilure()
		m["msg"] = "要收藏的博客不存在"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	if service.FindCollection(col) == true {
		m := config.ReturnFalilure()
		m["msg"] = "收藏已添加"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}

	_, err = service.AddCollection(col)
	if err != nil {

	}
	m := config.ReturnSuccess()
	m["msg"] = "收藏添加成功"
	data, _ := json.Marshal(m)
	ctx.Write([]byte(data))
	return
}

func (coll CollectionController) GetCollectionHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var col models.Collection
	err := ctx.Bind(&col)

	if err != nil {
		m := config.ReturnFalilure()
		m["msg"] = "收藏查询出错"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	if col.BlogId <= 0 {
		m := config.ReturnFalilure()
		m["msg"] = "要查询的博客不存在"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	if service.IsBlog(col.BlogId) == false {
		m := config.ReturnFalilure()
		m["msg"] = "要查询的博客不存在"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	var total int64
	total, err = service.CountCollection(total, col.BlogId)
	if err != nil {

	}
	m := config.ReturnSuccess()
	m["msg"] = "收藏查询成功"
	m["data"] = total
	data, _ := json.Marshal(m)
	ctx.Write([]byte(data))
	return
}

func (co CollectionController) JudgeColHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var col models.Collection
	err := ctx.Bind(&col)

	key, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := key.(*models.User).Username
	bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	id := bytes.Id
	col.UserId = id

	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		m := config.ReturnSuccess()
		m["msg"] = "收藏未添加"
		m["data"] = 0
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	if str != str2 {
		m := config.ReturnSuccess()
		m["msg"] = "收藏未添加"
		m["data"] = 0
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	if err != nil {
		m := config.ReturnFalilure()
		m["msg"] = "收藏查询出错"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	if col.BlogId <= 0 {
		m := config.ReturnFalilure()
		m["msg"] = "该博客不存在"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	if service.IsBlog(col.BlogId) == false {
		m := config.ReturnFalilure()
		m["msg"] = "该博客不存在"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}

	if service.FindCollection(col) == true {
		m := config.ReturnSuccess()
		m["msg"] = "收藏已添加"
		m["data"] = 1
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	m := config.ReturnSuccess()
	m["msg"] = "收藏未添加"
	m["data"] = 0
	data, _ := json.Marshal(m)
	ctx.Write([]byte(data))
	return
}

func (co CollectionController) DeleteColHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")

	var col models.Collection
	_ = ctx.BindAndValidate(&col)

	key, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := key.(*models.User).Username
	bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	id := bytes.Id
	col.UserId = id

	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}
	if service.IsBlog(col.BlogId) == false {
		m := config.ReturnFalilure()
		m["msg"] = "该博客不存在"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	if service.FindCollection(col) == false {
		m := config.ReturnFalilure()
		m["msg"] = "收藏取消失败"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	_, err := service.DelCollection(col)
	if err != nil {
		m := config.ReturnFalilure()
		m["msg"] = "收藏取消失败"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	m := config.ReturnSuccess()
	m["msg"] = "收藏取消成功"
	data, _ := json.Marshal(m)
	ctx.Write([]byte(data))
	return
}
