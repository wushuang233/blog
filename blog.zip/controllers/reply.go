package controllers

import (
	"blog/config"
	"blog/middleware"
	"blog/models"
	"blog/service"
	"context"
	"fmt"
	"github.com/cloudwego/hertz/pkg/app"
	"github.com/cloudwego/hertz/pkg/common/json"
	"github.com/cloudwego/hertz/pkg/common/utils"
)

type ReplyController struct{}

func (r ReplyController) AddReplyHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var reply models.Reply
	err := ctx.Bind(&reply)

	key, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := key.(*models.User).Username
	bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	id := bytes.Id
	reply.UserId = id

	str, _ := config.Rdb.Get(c, name).Result()
	str2 := string(ctx.GetHeader("Authorization"))
	if str == "" {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
		})
		return
	}
	if str != str2 {
		ctx.JSON(200, utils.H{
			"code": 404,
			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
		})
		return
	}
	_, err = service.GetUserInfoById(reply.RepliedId)
	if err != nil {
		m := config.ReturnFalilure()
		m["msg"] = "回复的用户不存在"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	_, err = service.AddReply(reply)
	if err != nil {
		m := config.ReturnFalilure()
		m["msg"] = "回复添加失败"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	m := config.ReturnSuccess()
	m["msg"] = "回复添加成功"
	data, _ := json.Marshal(m)
	ctx.Write([]byte(data))
	return
}

func (r ReplyController) ShowReplyHandler(c context.Context, ctx *app.RequestContext) {
	ctx.SetContentType("application/json; charset=utf-8")
	var replyPage models.ReplyPage
	_ = ctx.Bind(&replyPage)

	key, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
	name := key.(*models.User).Username
	bytes, _ := service.GetUserInfoByUsername(name)
	//UserId的设置
	id := bytes.Id

	if replyPage.Page <= 0 || replyPage.PageSize <= 0 {
		m := config.ReturnFalilure()
		m["msg"] = "回复显示出错"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	//获得page和pagesize，并且计算出totalPage
	p := replyPage.Page
	pageSize := replyPage.PageSize
	var total int64
	//tal, err := service.CountComment(total, replyPage.BlogId)
	//commentPage.PageTotal = tal
	//if err != nil {
	//
	//}
	offset := (p - 1) * pageSize
	//fmt.Println(pageSize, p, offset, total)
	//if service.IsBlog(replyPage.BlogId) == false {
	//	m := config.ReturnFalilure()
	//	m["msg"] = "该博客不存在"
	//	data, _ := json.Marshal(m)
	//	ctx.Write([]byte(data))
	//	return
	//}
	var replies []models.APIReply
	replies = make([]models.APIReply, 0)
	var rep []models.Reply
	rep, total = service.ShowReply(replyPage, offset)
	replyPage.PageTotal = total
	if rep == nil {
		m := config.ReturnFalilure()
		m["msg"] = "回复显示出错"
		data, _ := json.Marshal(m)
		ctx.Write([]byte(data))
		return
	}
	for i, _ := range rep {
		var re models.APIReply
		op, _ := service.GetUserOpByUsername(name)
		if op == 1 {
			re.Status = 1
		}
		if rep[i].UserId == id {
			re.Status = 1
		}
		user, _ := service.GetUserInfoById(rep[i].UserId)
		re.Author = user.NickName
		re.Avatar = user.Avatar
		re.Time = rep[i].UpdatedAt.Format("2006.01.02 15:04:05")
		re.Id = rep[i].Id
		re.UserId = rep[i].UserId
		re.Content = rep[i].Content
		re.CommentId = rep[i].CommentId
		re.RepliedId = rep[i].RepliedId
		u, _ := service.GetUserInfoById(rep[i].RepliedId)
		re.ReplyName = u.NickName
		replies = append(replies, re)
	}
	m := config.ReturnSuccess()
	m["msg"] = "回复显示成功"
	m["data"] = replies
	m["page"] = replyPage
	data, _ := json.Marshal(m)
	ctx.Write([]byte(data))
	return
}

//func (co CommentController) DelReplyHandler(c context.Context, ctx *app.RequestContext) {
//	ctx.SetContentType("application/json; charset=utf-8")
//	var comment models.Comment
//	err := ctx.Bind(&comment)
//
//	key, _ := ctx.Get(middleware.Jwtlogin().IdentityKey)
//	name := key.(*models.User).Username
//	bytes, _ := service.GetUserInfoByUsername(name)
//	//UserId的设置
//	id := bytes.Id
//	comment.UserId = id
//
//	str, _ := config.Rdb.Get(c, name).Result()
//	str2 := string(ctx.GetHeader("Authorization"))
//	if str == "" {
//		ctx.JSON(200, utils.H{
//			"code": 404,
//			"msg":  fmt.Sprintf("您的登录状态已过期，请重新登录"),
//		})
//		return
//	}
//	if str != str2 {
//		ctx.JSON(200, utils.H{
//			"code": 404,
//			"msg":  fmt.Sprintf("您已在别处登录，请重新登录"),
//		})
//		return
//	}
//	op, _ := service.GetUserOpByUsername(name)
//	if op == 1 {
//		err = service.OpDelComment(comment.Id)
//	}
//
//	if op == 0 {
//		if service.FindComment(comment.Id, id) != nil {
//			m := config.ReturnFalilure()
//			m["msg"] = "评论删除失败"
//			data, _ := json.Marshal(m)
//			ctx.Write([]byte(data))
//			return
//		}
//		err = service.DelComment(comment.Id, id)
//	}
//
//	if err != nil {
//		m := config.ReturnFalilure()
//		m["msg"] = "评论删除失败"
//		data, _ := json.Marshal(m)
//		ctx.Write([]byte(data))
//		return
//	}
//	m := config.ReturnSuccess()
//	m["msg"] = "评论删除成功"
//	data, _ := json.Marshal(m)
//	ctx.Write([]byte(data))
//	return
//}
