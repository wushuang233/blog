namespace go user_gorm
namespace py user_gorm
namespace java user_gorm

enum Code {
     Success         = 200
     ParamInvalid    = 404
     DBErr           = 502
}

enum Gender {
    Unknown = 0
    Male    = 1
    Female  = 2
}

struct User {
    1: i64 id
    2: string username
    3: string password
    4: string register
    5: i64 phone
    6: i64 blog
    7: i64 ban
    8: string avatar
    9: string email
    10:Gender gender
    11:string introduction
    12:i64 int
}
//创建用户的请求
struct CreateUserRequest{

    1: i64 id           (api.body="id",api.form="id",api.vd="$ >= 0")
    2: string username  (api.body="username",api.form="username",api.vd="api.vd=(len($) > 0 && len($) < 100)")
    3: string password  (api.body="password",api.form="password",api.vd="api.vd=(len($) > 0 && len($) < 100)")
    4: string register  (api.body="register",api.form="register",api.vd="api.vd=(len($) > 0 && len($) < 100)")
    5: i64 phone        (api.body="phone",api.form="phone",api.vd="$ >= 0")
    6: i64 blog         (api.body="blog",api.form="blog",api.vd="$ >= 0")
    7: i64 ban          (api.body="ban",api.form="ban",api.vd="$ >= 0")
    8: string avatar    (api.body="avatar",api.form="avatar",api.vd="api.vd=(len($) > 0 && len($) < 500)")
    9: string email     (api.body="email",api.form="email",api.vd="api.vd=(len($) > 0 && len($) < 100)")
    10:Gender gender    (api.body="gender", api.form="gender",api.vd="($ == 1||$ == 2)")
    11:string introduction  (api.body="introduction", api.form="introduction",api.vd="(len($) > 0 && len($) < 1000)")
    12:i64 age          (api.body="age", api.form="age",api.vd="$>=0")
}
//创建用户的响应
struct CreateUserResponse{
   1: Code code
   2: string msg
}
//查询用户的请求
struct QueryUserRequest{
   1: optional string Keyword (api.body="keyword", api.form="keyword",api.query="keyword")
   2: i64 page (api.body="page", api.form="page",api.query="page",api.vd="$ > 0")
   3: i64 page_size (api.body="page_size", api.form="page_size",api.query="page_size",api.vd="($ > 0 || $ <= 100)")
}
//查询用户的响应
struct QueryUserResponse{
   1: Code code
   2: string msg
   3: list<User> users
   4: i64 total
}
//删除用户的请求
struct DeleteUserRequest{
   1: i64    user_id   (api.path="user_id",api.vd="$>0")
}
//删除用户的响应
struct DeleteUserResponse{
   1: Code code
   2: string msg
}
//更新用户的请求
struct UpdateUserRequest{
    1: i64 id           (api.body="id",api.form="id",api.vd="$ >= 0")
    2: string username  (api.body="username",api.form="username",api.vd="api.vd=(len($) > 0 && len($) < 100)")
    3: string password  (api.body="password",api.form="password",api.vd="api.vd=(len($) > 0 && len($) < 100)")
    4: string register  (api.body="register",api.form="register",api.vd="api.vd=(len($) > 0 && len($) < 100)")
    5: i64 phone        (api.body="phone",api.form="phone",api.vd="$ >= 0")
    6: i64 blog         (api.body="blog",api.form="blog",api.vd="$ >= 0")
    7: i64 ban          (api.body="ban",api.form="ban",api.vd="$ >= 0")
    8: string avatar    (api.body="avatar",api.form="avatar",api.vd="api.vd=(len($) > 0 && len($) < 500)")
    9: string email     (api.body="email",api.form="email",api.vd="api.vd=(len($) > 0 && len($) < 100)")
    10:Gender gender    (api.body="gender", api.form="gender",api.vd="($ == 1||$ == 2)")
    11:string introduction  (api.body="introduction", api.form="introduction",api.vd="(len($) > 0 && len($) < 1000)")
    12:i64 age          (api.body="age", api.form="age",api.vd="$>=0")
}
//更新用户的响应
struct UpdateUserResponse{
   1: Code code
   2: string msg
}
service UserService {
   UpdateUserResponse UpdateUser(1:UpdateUserRequest req)(api.post="/user/update/:user_id")
   DeleteUserResponse DeleteUser(1:DeleteUserRequest req)(api.post="/user/delete/:user_id")
   QueryUserResponse  QueryUser(1: QueryUserRequest req)(api.post="/user/query/")
   CreateUserResponse CreateUser(1:CreateUserRequest req)(api.post="/user/register/")
}