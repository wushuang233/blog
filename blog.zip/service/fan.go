package service

import (
	"blog/dao"
	"blog/models"
)

// 统计所有粉丝

func CountFan(total int64, userId int) (int64, error) {
	err := dao.Db.Model(&models.Fan{}).Where("author_id = ?", userId).Count(&total).Error
	return total, err
}

//判断是否是粉丝

func FindFan(authorId int, fanId int) bool {
	var fan models.Fan
	var total int64
	err := dao.Db.Model(&models.Fan{}).Where("fan_id", fanId).Where("author_id = ?", authorId).Find(&fan).Count(&total).Error
	if err != nil || total == 0 {
		return false
	}
	return true
}

//关注作者

func FocusFan(authorId int, fanId int) error {
	var fan models.Fan
	fan.FanId = fanId
	fan.AuthorId = authorId
	err := dao.Db.Model(&models.Fan{}).Create(&fan).Error
	return err
}

//取关作者

func DelFan(authorId int, fanId int) error {
	var fan models.Fan
	fan.FanId = fanId
	fan.AuthorId = authorId
	err := dao.Db.Model(&models.Fan{}).Where("author_id = ?", authorId).Where("fan_id = ?", fanId).Delete(&fan).Error
	return err
}

//获取关注列表

func GetFocus(userId int, offset int, pageSize int) ([]models.Fan, error, int64) {
	var focus []models.Fan
	var total int64
	err := dao.Db.Model(&models.Fan{}).Where("fan_id = ?", userId).Offset(offset).Limit(pageSize).Find(&focus).Count(&total).Error
	return focus, err, total
}

//获取粉丝列表

func GetFans(userId int, offset int, pageSize int) ([]models.Fan, error, int64) {
	var focus []models.Fan
	var total int64
	err := dao.Db.Model(&models.Fan{}).Where("author_id = ?", userId).Offset(offset).Limit(pageSize).Find(&focus).Count(&total).Error
	return focus, err, total
}
