package service

import (
	"blog/dao"
	"blog/models"
)

// 增加博客
func AddBlog(blog models.Blog) (int, error) {
	err := dao.Db.Create(&blog).Error
	return blog.Id, err
}

// 修改博客
func ChangeBlog(blog models.Blog) (int, error) {
	err := dao.Db.Model(&blog).Where("user_id = ?", blog.UserId).Where("id = ?", blog.Id).Select("Title", "content", "category_id", "resume", "front").Updates(models.Blog{Title: blog.Title, Content: blog.Content, CategoryId: blog.CategoryId, Resume: blog.Resume, Front: blog.Front}).Error
	return blog.Id, err
}

//// 修改博客浏览量
//func ChangeView(blog models.Blog) (int, error) {
//	err := dao.Db.Model(&blog).Where("user_id = ?", blog.UserId).Where("id = ?", blog.Id).Select("view").Updates(models.Blog{View: blog.View}).Error
//	return blog.Id, err
//}

// 删除博客
func DelBlog(blog models.Blog) (int, error) {
	err := dao.Db.Where("user_id = ?", blog.UserId).Where("id = ?", blog.Id).Delete(&blog).Error
	return blog.Id, err
}

// 判断博客是否属于用户
func JudBlog(blog models.Blog) bool {
	err := dao.Db.Where("user_id = ?", blog.UserId).Where("id = ?", blog.Id).First(&blog).Error
	if err != nil {
		return false
	}
	return true
}

// 判断博客是否属于用户的草稿箱、审核区、通过区
func JudgeBlog(blog models.Blog) bool {
	err := dao.Db.Where("user_id = ?", blog.UserId).Where("id = ?", blog.Id).Where("status = ?", blog.Status).First(&blog).Error
	if err != nil {
		return false
	}
	return true
}

// 统计所有博客
func CountBlog(total int64, categoryId int) (int64, error) {
	err := dao.Db.Model(models.Blog{}).Where("status = ?", 2).Where("category_id = ?", categoryId).Count(&total).Error
	return total, err
}

// 统计用户各个状态博客
func CountStatus(userId int, total int64, status int) (int64, error) {
	err := dao.Db.Model(models.Blog{}).Where("user_id = ?", userId).Where("status = ?", status).Count(&total).Error
	return total, err
}

// 得到所有博客
func ShowBlog(page models.Page, offset int) []models.Blog {
	err := dao.Db.Order("updated_at DESC").Offset(offset).Limit(page.PageSize).Find(&page.Data).Error
	if err != nil {
		return nil
	}
	return page.Data
}

// 得到所有状态博客
func ShowStatus(page models.Page, offset int, status int, userId int) []models.Blog {
	err := dao.Db.Order("updated_at DESC").Where("user_id = ?", userId).Where("status = ?", status).Offset(offset).Limit(page.PageSize).Find(&page.Data).Error
	if err != nil {
		return nil
	}
	return page.Data
}

// 得到6个博客名称
func ShowName(status int, userId int) ([]string, []int) {
	var name []string
	var ids []int
	//var blogs []models.Blog
	err := dao.Db.Model(&models.Blog{}).Order("id DESC").Where("user_id = ?", userId).Where("status = ?", status).Select("title").Limit(6).Find(&name).Error
	if err != nil {
		return nil, nil
	}
	err = dao.Db.Model(&models.Blog{}).Order("id DESC").Where("user_id = ?", userId).Where("status = ?", status).Select("id").Limit(6).Find(&ids).Error
	if err != nil {
		return nil, nil
	}
	//fmt.Println(name)
	//for i, _ := range blogs {
	//	name[i] = blogs[i].Title
	//}
	return name, ids
}

// 得到博客并且分类
func ShowBlogByCategory(page models.Page, offset int) []models.Blog {
	err := dao.Db.Order("top DESC,updated_at DESC").Where("category_id = ?", page.CategoryId).Where("status = ?", 2).Offset(offset).Limit(page.PageSize).Find(&page.Data).Error
	if err != nil {
		return nil
	}
	return page.Data
}

// 得到博客并且分类【按热度】
func ShowBlogByHot(page models.Page, offset int) []models.Blog {
	//err := dao.Db.Order("top DESC").Where("category_id = ?", page.CategoryId).Offset(offset).Limit(page.PageSize).Find(&page.Data).Error
	err := dao.Db.Table("tb_blog").
		Select("tb_blog.*").
		Joins("INNER JOIN tb_view ON tb_blog.id = tb_view.blog_id").
		Order("tb_blog.top DESC,tb_view.view DESC").
		Where("category_id = ?", page.CategoryId).
		Where("status = ?", 2).
		Offset(offset).
		Limit(page.PageSize).
		Find(&page.Data).Error
	if err != nil {
		return nil
	}
	return page.Data
}

//获取博客详情信息

func GetBlog(id int) (models.Blog, error) {
	var blog models.Blog
	blog.Id = id
	err := dao.Db.First(&blog).Error
	//if err != nil {
	//	return blog, err
	//}
	return blog, err
}

// 判断博客id是否存在
func IsBlog(id int) bool {
	var blog models.Blog
	blog.Id = id
	err := dao.Db.First(&blog).Error
	if err != nil {
		return false
	}
	return true
}

// 修改博客的状态
func ChangeStatus(id int, status int) error {
	err := dao.Db.Model(&models.Blog{}).Where("id = ?", id).Select("status").Updates(models.Blog{Status: status}).Error
	return err
}

// 通过博客id获取博客状态
func GetStatus(blogId int) (int, error) {
	var blog models.Blog
	err := dao.Db.Model(&models.Blog{}).Where("id = ?", blogId).Select("status").Find(&blog).Error
	return blog.Status, err
}

// 模糊搜索
func SearchBlog(searchName string, offset int, pageSize int) ([]models.Blog, error, int64) {
	var blogs []models.Blog
	var total int64
	err := dao.Db.Model(&models.Blog{}).Where("title LIKE ?", "%"+searchName+"%").Offset(offset).Limit(pageSize).Find(&blogs).Count(&total).Error
	return blogs, err, total
}
