package service

import (
	"blog/dao"
	"blog/models"
)

func AddLike(like models.Like) (int, error) {
	err := dao.Db.Create(&like).Error
	return like.Id, err
}

func FindLike(like models.Like) bool {
	err := dao.Db.Where("blog_id = ?", like.BlogId).Where("user_id = ?", like.UserId).First(&like).Error
	if err != nil {
		return false
	}
	return true
}

// 统计所有点赞
func CountLike(total int64, blogId int) (int64, error) {
	err := dao.Db.Model(&models.Like{}).Where("blog_id = ?", blogId).Count(&total).Error
	return total, err
}

// 删除点赞
func DelLike(like models.Like) (int, error) {
	err := dao.Db.Where("user_id = ?", like.UserId).Where("blog_id = ?", like.BlogId).Delete(&like).Error
	return like.Id, err
}
