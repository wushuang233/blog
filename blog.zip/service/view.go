package service

import (
	"blog/dao"
	"blog/models"
)

//// 统计所有浏览量
//func CountView(total int64, blogId int) (int64, error) {
//	//err := dao.Db.Model(&models.View{}).Where("blog_id = ?", blogId).Count(&total).Error
//	//return total, err
//}

// 添加浏览量
func SetView(blogId int) error {
	view, err := GetView(blogId)
	view = view + 1
	err = dao.Db.Model(&models.View{}).Where("blog_id = ?", blogId).Updates(models.View{View: view}).Error
	return err
}

// 获取浏览量
func GetView(blogId int) (int64, error) {
	var view models.View
	err := dao.Db.Model(&models.View{}).Where("blog_id = ?", blogId).Find(&view).Error
	//fmt.Println(view.View, err)
	return view.View, err
}

// 添加浏览量
func AddView(view models.View) error {
	err := dao.Db.Model(&models.View{}).Create(&view).Error
	//fmt.Println("LLL")
	return err
}
