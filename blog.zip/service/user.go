package service

import (
	"blog/config"
	"blog/dao"
	"blog/models"
	"time"
)

type APIUser struct {
	Id           int       `json:"id"`
	Username     string    `json:"username"`
	Phone        string    `json:"phone"`
	Ban          bool      `json:"ban"`
	Avatar       string    `json:"avatar"`
	Email        string    `json:"email"`
	Gender       int       `json:"gender"`
	Introduction string    `json:"introduction"`
	Op           int       `json:"op"`
	NickName     string    `json:"nick_name"`
	Birthday     string    `json:"birthday"`
	CreatedAt    time.Time `json:"created_At"`
	Time         string    `json:"time"`
}

// 获取用户
func GetUserInfoByUsername(username string) (models.User, error) {
	var user models.User
	err := dao.Db.Where("username = ?", username).First(&user).Error
	return user, err
}

// 通过名字获取用户
func GetUserInfoByName(username string) (models.User, error) {
	var user models.User
	err := dao.Db.Model(&models.User{}).Where("username = ?", username).Find(&APIUser{}).First(&user).Error
	return user, err
}

// 通过邮箱获取用户
func GetUserInfoByEmail(email string) (models.User, error) {
	var user models.User
	err := dao.Db.Where("email = ?", email).First(&user).Error
	return user, err
}

// 通过id获取用户
func GetUserInfoById(id int) (models.User, error) {
	var user models.User
	err := dao.Db.Model(&models.User{}).Where("id = ?", id).Find(&APIUser{}).First(&user).Error
	return user, err
}

// 增加用户
func AddUser(user models.User) (int, error) {
	err := dao.Db.Create(&user).Error
	return user.Id, err
}

// 判断用户是否为管理员
func GetUserOpByUsername(username string) (int, error) {
	var user models.User
	err := dao.Db.Where("username = ?", username).First(&user).Error
	return user.Op, err
}

// 更新用户
func SaveUser(user models.User) (int, error) {
	err := dao.Db.Model(&user).Select("Phone", "Email", "Gender", "Introduction", "NickName", "Birthday").Updates(models.User{Phone: user.Phone, Email: user.Email, Gender: user.Gender, Introduction: user.Introduction, NickName: user.NickName, Birthday: user.Birthday}).Error
	return user.Id, err
}

// 更新用户头像
func SaveAvatar(user models.User) (int, error) {
	err := dao.Db.Model(&models.User{}).Where("id = ?", user.Id).Select("Avatar").Updates(models.User{Avatar: user.Avatar}).Error
	return user.Id, err
}

// 修改密码
func ChangePassword(user models.User) (int, error) {
	err := dao.Db.Model(&user).Select("Password").Updates(models.User{Password: config.EncryMd5(user.Password)}).Error
	return user.Id, err
}

// 模糊搜索
func SearchUser(searchName string, offset int, pageSize int) ([]models.User, error, int64) {
	var users []models.User
	var total int64
	err := dao.Db.Model(&models.User{}).Where("nick_name LIKE ?", "%"+searchName+"%").Offset(offset).Limit(pageSize).Find(&users).Count(&total).Error
	return users, err, total
}

// 获取用户的所有通知
func GetNotice(page models.Page, offset int, userId int) ([]models.Notice, error, int64) {
	var notices []models.Notice
	var total int64
	err := dao.Db.Model(&models.Notice{}).Order("updated_at DESC").Where("user_id = ? or user_id = ?", userId, 0).Offset(offset).Limit(page.PageSize).Find(&notices).Count(&total).Error
	return notices, err, total
}

func GetNoticeInfo(id int, userId int) (models.Notice, error) {
	var notice models.Notice
	err := dao.Db.Model(&models.Notice{}).Where("id = ?", id).Where("user_id = 0 or user_id = ?", userId).Find(&notice).Error
	return notice, err
}
