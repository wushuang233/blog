package service

import (
	"blog/dao"
	"blog/models"
)

func FindCollection(col models.Collection) bool {
	err := dao.Db.Where("blog_id = ?", col.BlogId).Where("user_id = ?", col.UserId).First(&col).Error
	if err != nil {
		return false
	}
	return true
}

func AddCollection(col models.Collection) (int, error) {
	err := dao.Db.Create(&col).Error
	return col.Id, err
}

// 统计所有收藏
func CountCollection(total int64, blogId int) (int64, error) {
	err := dao.Db.Model(&models.Collection{}).Where("blog_id = ?", blogId).Count(&total).Error
	return total, err
}

// 统计用户的所有收藏
func CountUserCollection(total int64, userId int) (int64, error) {
	err := dao.Db.Model(&models.Collection{}).Where("user_id = ?", userId).Count(&total).Error
	return total, err
}

// 返回用户的所有收藏的博客id
func ReturnUserCollection(page models.Page, offset int, userId int) ([]int, error) {
	var ids []int
	err := dao.Db.Model(&models.Collection{}).Order("id DESC").Where("user_id = ?", userId).Select("blog_id").Offset(offset).Limit(page.PageSize).Find(&ids).Error
	return ids, err
}

// 删除收藏
func DelCollection(col models.Collection) (int, error) {
	err := dao.Db.Where("user_id = ?", col.UserId).Where("blog_id = ?", col.BlogId).Delete(&col).Error
	return col.Id, err
}
