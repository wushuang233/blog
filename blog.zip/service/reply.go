package service

import (
	"blog/dao"
	"blog/models"
)

// 增加回复
func AddReply(reply models.Reply) (int, error) {
	err := dao.Db.Create(&reply).Error
	return reply.Id, err
}

// 得到所有评论
func ShowReply(page models.ReplyPage, offset int) ([]models.Reply, int64) {
	var total int64
	err := dao.Db.Model(&models.Reply{}).Order("id DESC").Where("comment_id = ?", page.CommentId).Offset(offset).Limit(page.PageSize).Find(&page.Data).Count(&total).Error
	if err != nil {
		return nil, total
	}
	return page.Data, total
}

//// 统计所有评论
//func CountComment(total int64, blogId int) (int64, error) {
//	err := dao.Db.Model(&models.Comment{}).Where("blog_id = ?", blogId).Count(&total).Error
//	return total, err
//}

//// 管理员删除评论
//func OpDelComment(id int) error {
//	var comment models.Comment
//	comment.Id = id
//	err := dao.Db.Model(&models.Comment{}).Where("id = ?", id).Delete(&comment).Error
//	return err
//}
//
//// 删除评论
//func DelComment(id int, userId int) error {
//	var comment models.Comment
//	comment.Id = id
//	err := dao.Db.Model(&models.Comment{}).Where("user_id = ?", userId).Where("id = ?", id).Delete(&comment).Error
//	return err
//}

// 查找回复
func FindReply(id int, userId int) error {
	var reply models.Reply
	reply.Id = id
	err := dao.Db.Model(&models.Comment{}).Where("user_id = ?", userId).Where("id = ?", id).First(&reply).Error
	//fmt.Println(err)
	return err
}
