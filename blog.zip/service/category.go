package service

import (
	"blog/dao"
	"blog/models"
)

// 增加类别
// 管理员限定
func AddCategory(category models.Category) (int, error) {
	err := dao.Db.Create(&category).Error
	return category.Id, err
}

//搜索类别是否存在

func FindId(id int) bool {
	var category = models.Category{Id: id}
	err := dao.Db.First(&category).Error
	if err != nil {
		return false
	}

	return true
}

func AllCategory() ([]models.Category, error) {
	var categories []models.Category
	err := dao.Db.Model(models.Category{}).Find(&categories).Error
	return categories, err
}

func GetCategory(id int) (string, error) {
	var name string
	err := dao.Db.Model(&models.Category{}).Where("id = ?", id).Select("name").Find(&name).Error
	return name, err
}
