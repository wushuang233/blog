package service

import (
	"blog/dao"
	"blog/models"
)

// 获取Op
func GetOp(offset int, pageSize int) ([]models.User, int64, error) {
	var users []models.User
	var total int64
	err := dao.Db.Model(&models.User{}).Where("op = ?", 1).Where("ban = ?", false).Offset(offset).Limit(pageSize).Find(&users).Count(&total).Error
	return users, total, err
}

// 获取普通user
func GetNormal(offset int, pageSize int) ([]models.User, int64, error) {
	var users []models.User
	var total int64
	err := dao.Db.Model(&models.User{}).Where("op = ?", 0).Where("ban = ?", false).Offset(offset).Limit(pageSize).Find(&users).Count(&total).Error
	return users, total, err
}

// 获取ban
func GetBan(offset int, pageSize int) ([]models.User, int64, error) {
	var users []models.User
	var total int64
	err := dao.Db.Model(&models.User{}).Where("ban = ?", true).Offset(offset).Limit(pageSize).Find(&users).Count(&total).Error
	return users, total, err
}

// 封禁用户
func BanUser(user models.User) error {
	err := dao.Db.Model(&models.User{}).Where("id = ?", user.Id).Where("ban = ?", false).Where("op = ?", 0).Select("ban").Update("ban", true).Error
	return err
}

// 解封用户
func OpenUser(user models.User) error {
	err := dao.Db.Model(&models.User{}).Where("id = ?", user.Id).Where("ban = ?", true).Select("ban").Update("ban", false).Error
	return err
}

// op得到所有状态博客
func OpGetStatus(offset int, pageSize int, status int) ([]models.Blog, int64) {
	var blogs []models.Blog
	var total int64
	err := dao.Db.Order("updated_at DESC").Where("status = ?", status).Offset(offset).Limit(pageSize).Find(&blogs).Count(&total).Error
	if err != nil {
		return nil, 0
	}
	return blogs, total
}

// op审核博客
func OpCheck(blogId int, status int) error {
	err := dao.Db.Model(&models.Blog{}).Order("updated_at DESC").Where("status = ?", 1).Where("id = ?", blogId).Select("status").Updates(&models.Blog{Status: status}).Error
	return err
}

// op删除博客
//
//	func OpDelBlog(blog models.Blog) error {
//		err := dao.Db.Model(&models.Blog{}).Where("id = ?").Delete(&blog).Error
//		return err
//	}
func OpDelBlog(blogId int, status int) error {
	err := dao.Db.Model(&models.Blog{}).Order("updated_at DESC").Where("status = ?", 2).Where("id = ?", blogId).Select("status").Updates(&models.Blog{Status: status}).Error
	return err
}

func OpTopBLog(blogId int) error {
	err := dao.Db.Model(&models.Blog{}).Where("id = ?", blogId).Where("top = ?", 0).Select("top").UpdateColumns(&models.Blog{Top: 1}).Error
	return err
}

func OpDelTopBLog(blogId int) error {
	err := dao.Db.Model(&models.Blog{}).Where("id = ?", blogId).Where("top = ?", 1).Select("top").UpdateColumns(&models.Blog{Top: 0}).Error
	return err
}

// 管理员发布通知
func OpAddNotice(notice models.Notice) error {
	notice.Status = 0
	err := dao.Db.Model(&models.Notice{}).Create(&notice).Error
	return err
}

// 管理员更新通知
func OpPutNotice(notice models.Notice) error {
	notice.Status = 0
	err := dao.Db.Model(&models.Notice{}).Where("id = ?", notice.Id).Where("status = ?", 0).UpdateColumns(&models.Notice{
		Title:   notice.Title,
		Content: notice.Content,
	}).Error
	return err
}

// 查看是否是管理员自己的通知
func CheckNotice(id int) bool {
	var notice models.Notice
	err := dao.Db.Model(&models.Notice{}).Where("id = ?", id).Where("status = ?", 0).First(&notice).Error
	//fmt.Println(err)
	if err != nil {
		return false
	}
	return true
}

// 系统通知
func SysAddNotice(notice models.Notice) error {
	notice.Status = 1
	err := dao.Db.Model(&models.Notice{}).Create(&notice).Error
	return err
}

// 获取所有管理员发的通知
func GetOpNotice(page models.Page, offset int) ([]models.Notice, error, int64) {
	var notices []models.Notice
	var total int64
	err := dao.Db.Model(&models.Notice{}).Order("updated_at DESC").Where("status = ?", 0).Offset(offset).Limit(page.PageSize).Find(&notices).Count(&total).Error
	return notices, err, total
}

// 删除管理员发的通知
func DelOpNotice(id int) error {
	var notice models.Notice
	err := dao.Db.Model(&models.Notice{}).Where("status = ?", 0).Where("id = ?", id).Delete(&notice).Error
	return err
}
