package config

const (
	Mysqldb = "root:dd5996188@tcp(127.0.0.1:3306)/blog?charset=utf8"
)
