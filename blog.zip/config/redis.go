package config

import "github.com/go-redis/redis/v8"

var Rdb *redis.Client

func init() {
	// redis 连接
	Rdb = redis.NewClient(&redis.Options{
		Addr:     "localhost:6379",
		Password: "", // 密码
		DB:       0,  // 数据库号
	})

}
