package middleware

import (
	"blog/config"
	"blog/models"
	"blog/service"
	"context"
	"github.com/cloudwego/hertz/pkg/app"
	"github.com/cloudwego/hertz/pkg/common/utils"
	"github.com/hertz-contrib/jwt"
	"log"
	"net/http"
	"time"
)

var identityKey = "id"
var user3 models.User

type login struct {
	Username string `form:"username,required" json:"username,required"`
	Password string `form:"password,required" json:"password,required"`
}

func Jwtlogin() *jwt.HertzJWTMiddleware {
	// the jwt middleware
	AuthMiddleware, err := jwt.New(&jwt.HertzJWTMiddleware{
		Realm:       "test zone",
		Key:         []byte("secret key"),
		Timeout:     168 * time.Hour,
		MaxRefresh:  time.Hour,
		IdentityKey: identityKey,
		PayloadFunc: func(data interface{}) jwt.MapClaims {
			if v, ok := data.(*models.User); ok {
				return jwt.MapClaims{
					identityKey: v.Username,
				}
			}
			return jwt.MapClaims{}
		},
		IdentityHandler: func(ctx context.Context, c *app.RequestContext) interface{} {
			claims := jwt.ExtractClaims(ctx, c)
			return &models.User{
				Username: claims[identityKey].(string),
			}
		},
		Authenticator: func(ctx context.Context, c *app.RequestContext) (interface{}, error) {
			//string_res, _ := config.Rdb.Get(ctx, "token").Result()
			//fmt.Println(string_res)
			//if string_res != "" {
			//	c.JSON(200, map[string]interface{}{
			//		"code": 200,
			//		"msg":  "已登录",
			//	})
			//}
			var loginVals login
			if err := c.BindAndValidate(&loginVals); err != nil {
				return "", jwt.ErrMissingLoginValues
			}
			userID := loginVals.Username
			userpswd := loginVals.Password
			user3.Username = userID
			//fmt.Println(userID)
			//_ = loginVals.Password
			user2, error := service.GetUserInfoByUsername(userID)
			user3.Ban = user2.Ban
			if user2.Ban == true {
				c.JSON(200, utils.H{
					"code": 200,
					"msg":  "你的账户已被封禁，请联系管理员qq75476676解封",
				})
				return nil, nil
			}
			if user2.Password == config.EncryMd5(userpswd) {

				if error == nil {
					return &models.User{
						Username: userID,
					}, nil
				}
			}
			return nil, jwt.ErrFailedAuthentication
		},
		Authorizator: func(data interface{}, ctx context.Context, c *app.RequestContext) bool {
			if _, ok := data.(*models.User); ok {
				return true
			}

			return false
		},
		Unauthorized: func(ctx context.Context, c *app.RequestContext, code int, message string) {
			c.JSON(code, map[string]interface{}{
				"code":    code,
				"message": message,
			})
		},
		LoginResponse: func(ctx context.Context, c *app.RequestContext, code int, token string, expire time.Time) {
			name := user3.Username
			op, _ := service.GetUserOpByUsername(name)
			//if user3.Ban == true{
			//	return nil
			//}
			_, err := config.Rdb.Set(ctx, name, token, 168*time.Hour).Result()
			if err != nil {
				//panic(err)
			}
			if op == 1 && user3.Ban != true {
				c.JSON(http.StatusOK, map[string]interface{}{
					"code":   201,
					"token":  token,
					"expire": expire.Format(time.RFC3339),
				})
			} else if op == 0 && user3.Ban != true {
				c.JSON(http.StatusOK, map[string]interface{}{
					"code":   200,
					"token":  token,
					"expire": expire.Format(time.RFC3339),
				})
			}
			//c.JSON(http.StatusOK, map[string]interface{}{
			//	"code":   201,
			//	"token":  token,
			//	"expire": expire.Format(time.RFC3339),
			//})
		},
	})
	if err != nil {
		log.Fatal("JWT Error:" + err.Error())
	}
	errInit := AuthMiddleware.MiddlewareInit()

	if errInit != nil {
		log.Fatal("authMiddleware.MiddlewareInit() Error:" + errInit.Error())
	}

	return AuthMiddleware
}

func JwtOP() *jwt.HertzJWTMiddleware {
	// the jwt middleware
	AuthMiddleware, err := jwt.New(&jwt.HertzJWTMiddleware{
		Realm:       "test zone",
		Key:         []byte("secret key"),
		Timeout:     time.Hour,
		MaxRefresh:  time.Hour,
		IdentityKey: identityKey,
		PayloadFunc: func(data interface{}) jwt.MapClaims {
			if v, ok := data.(*models.User); ok {
				return jwt.MapClaims{
					identityKey: v.Username,
				}
			}
			return jwt.MapClaims{}
		},
		IdentityHandler: func(ctx context.Context, c *app.RequestContext) interface{} {
			claims := jwt.ExtractClaims(ctx, c)
			return &models.User{
				Username: claims[identityKey].(string),
			}
		},
		Authenticator: func(ctx context.Context, c *app.RequestContext) (interface{}, error) {
			var loginVals login
			if err := c.BindAndValidate(&loginVals); err != nil {
				return "", jwt.ErrMissingLoginValues
			}
			userID := loginVals.Username
			userpswd := loginVals.Password

			//fmt.Println(userID)
			//_ = loginVals.Password
			user2, error := service.GetUserInfoByUsername(userID)
			if user2.Password == config.EncryMd5(userpswd) {
				user3.Op = user2.Op
				if error == nil {
					return &models.User{
						Username: userID,
						Op:       user2.Op,
					}, nil
				}
			}
			return nil, jwt.ErrFailedAuthentication
		},
		Authorizator: func(data interface{}, ctx context.Context, c *app.RequestContext) bool {
			if us, ok := data.(*models.User); ok {
				name := us.Username
				op, _ := service.GetUserOpByUsername(name)
				if op == 1 {
					return true
				}
				return false
			}

			return false
		},
		Unauthorized: func(ctx context.Context, c *app.RequestContext, code int, message string) {
			c.JSON(code, map[string]interface{}{
				"code":    code,
				"message": message,
			})
		},
	})
	if err != nil {
		log.Fatal("JWT Error:" + err.Error())
	}
	errInit := AuthMiddleware.MiddlewareInit()

	if errInit != nil {
		log.Fatal("authMiddleware.MiddlewareInit() Error:" + errInit.Error())
	}

	return AuthMiddleware
}
